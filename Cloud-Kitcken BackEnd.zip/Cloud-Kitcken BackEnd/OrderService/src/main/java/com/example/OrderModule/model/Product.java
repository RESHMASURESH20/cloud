package com.example.OrderModule.model;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class Product {

    private int productid;
    private String productname;
    private double price;
    private int quantity;

}