package com.example.OrderModule.Constant;

public interface Constant {
     String ORDERS="/orders";
     String PLACEORDER="/placeOrder";
     String ADDTOORDER="/addToOrder";
     String  GETORDER="/getOrder";
     String GETORDERBYID="/getOrderById/{id}";
     String GETALLORDERBYID="/getAllOrderById/{id}";
     String CHECKFORSTATUS="/checkForStatus/{id}/str";
     String CANCELORDER="/cancelOrder/{str}";
     String ORDERDELIVERED="/orderDelivered/{str}";
     String ID="id";
     String STR="str";
     String DATANOTFOUND="Data not found";
     String KAFKAADDRESS="127.0.0.1:9092";
     String GROUP_ID="group_id";
     String ORDERTABLE="order";
     String QUERY="{'userid':?0}";
     String CARTURL="http://localhost:8898/cart/deleteCartItem/";
//     String CARTURL="http://10.30.1.86:8898/cart/deleteCartItem/";
     String UNABLETOINSERT="Unable To Insert";
     String  CANCELLED="Cancelled";
     String  DELIVERED="Delivered";
     String  DATAFORMAT="dd/MM/yyyy HH:mm:ss";
     String  KAFKA_TOPIC="placeOrder";
     int ORDERNO=120000;
     int ORDER_DECLINE=10;
     int THOUSAND=1000;
     int TWENTYFOUR=24;
     int SIXTY= 60;
     int ZERO=0;
     int THIRTY=30;
     int YEAR=365;

}
