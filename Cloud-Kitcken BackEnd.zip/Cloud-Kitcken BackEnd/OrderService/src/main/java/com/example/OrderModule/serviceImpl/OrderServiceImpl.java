package com.example.OrderModule.serviceImpl;

import com.example.OrderModule.Constant.Constant;
import com.example.OrderModule.Respository.OrderRepository;
import com.example.OrderModule.Service.OrderService;
import com.example.OrderModule.customException.DataNotFoundException;
import com.example.OrderModule.model.Order;
import com.example.OrderModule.model.OrderDto;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.dao.DataAccessException;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;


@Service
public class OrderServiceImpl implements OrderService {


    private static long ORDERID=Constant.ORDERNO;

    @Autowired
    OrderRepository orderRepository;

    @Autowired
    ObjectMapper objectMapper;

    @Autowired
    private KafkaTemplate<String, String> kafkaTemplate;

    private RestTemplate restTemplate;

    public OrderServiceImpl(RestTemplateBuilder restTemplateBuilder) {

        restTemplate = restTemplateBuilder.build();
    }


    public OrderDto modelToDto(Order order) {
        OrderDto orderDto = new OrderDto();
        orderDto.setName(order.getName());
        orderDto.setPhonenumber(order.getPhonenumber());
        orderDto.setAlternativenumber(order.getAlternativenumber());
        orderDto.setOrderId(order.getOrderId());
        orderDto.setProduct(order.getProduct());
        orderDto.setUserId(order.getUserId());
        orderDto.setTotalprice(order.getTotalprice());
        orderDto.setDate(order.getDate());
        orderDto.setStatus(order.getStatus());
        orderDto.setNetprice(order.getNetprice());
        orderDto.setUserName(order.getUserName());
        orderDto.setOrderdate(order.getOrderdate());
        orderDto.setDeclineTime(order.getDeclineTime());
        return orderDto;
    }


    private void clearCard(int userId) {
        restTemplate.delete(Constant.CARTURL + userId + "", userId, String.class);
    }



    @Override
    public boolean addToOrder(List<Order> orders) {
        try {
               if(!Objects.isNull(orders)) {
                   for (Order order : orders)
                       order.setOrderId(String.valueOf(ORDERID++));
                   orderRepository.saveAll(orders);
                   return true;
               }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return false;
    }


    @Override
    public String placeOrderDB(Order order) {
        try {
            if(!Objects.isNull(order)) {
                order.setOrderId(String.valueOf(ORDERID++));
                // sendToCart(order);
//                clearCard(order.getUserId());
                System.out.println(order.toString());
                Calendar c = Calendar.getInstance();
                c.setTime(order.getOrderdate());
                c.add(Calendar.MINUTE,Constant.ORDER_DECLINE);
                Date date=c.getTime();
                order.setDeclineTime(date);
                Order orders = orderRepository.save(order);
                System.out.println(orders);

                return orders.getOrderId();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return Constant.UNABLETOINSERT;
    }




    @Override
    public boolean cancelOrder(String str) throws DataNotFoundException {
        try {

            Optional<Order> order = orderRepository.findById(str);
            order.get().setStatus(Constant.CANCELLED);
            orderRepository.save(order.get());
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            throw new DataNotFoundException();
        }
    }


    @Override
    public boolean orderDelivered(String str) throws DataNotFoundException {
        try {
            Optional<Order> order = orderRepository.findById(str);
            System.out.println(order.toString());
            order.get().setStatus(Constant.DELIVERED);
            orderRepository.save(order.get());
            System.out.println(order.toString());
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            throw new DataNotFoundException();
        }
    }


    @Override
    public List<OrderDto> getOrder() throws DataNotFoundException {
        try {
            List<Order> orders = orderRepository.findAll();
            List<OrderDto> ListOforderDtos = new ArrayList<>();
            OrderDto orderDto;
            for (Order order : orders) {
                orderDto = modelToDto(order);
                ListOforderDtos.add(orderDto);
            }
            return ListOforderDtos;
        } catch (Exception e) {
            e.printStackTrace();
            throw new DataNotFoundException();
        }
    }


    @Override
    public Order getOrderById(String id) throws DataNotFoundException {
        try {
            Optional<Order> order = orderRepository.findById(id);
            if (!order.isPresent())
                throw new DataNotFoundException();
            return order.get();
        } catch (DataAccessException e) {
            throw new DataNotFoundException();
        }
    }


    @Override
    public List<OrderDto> getAllOrderOfId(int id) throws DataNotFoundException {
        try {
            List<OrderDto> ListOforderDtos = new ArrayList<>();
            OrderDto orderDto;
            for (Order order : orderRepository.findAllByUserId(id)) {
                orderDto = modelToDto(order);
                ListOforderDtos.add(orderDto);
            }
            return ListOforderDtos;
        } catch (Exception e) {
            throw new DataNotFoundException();
        }
    }

    @Override
    public boolean checkForOrderStatus(String id, String str) throws DataNotFoundException {
        try {
            Optional<Order> order = orderRepository.findById(id);
            if (!Objects.isNull(order)) {

                Date d1 = new SimpleDateFormat(Constant.DATAFORMAT).parse(order.get().getDate());
                System.out.println(order.get().getDate());
                Date d2 = new SimpleDateFormat(Constant.DATAFORMAT).parse(str);
                System.out.println(str);
                long difference_In_Time = d2.getTime() - d1.getTime();
                long difference_In_Seconds = (difference_In_Time / Constant.THOUSAND) % Constant.SIXTY;
                long difference_In_Minutes = (difference_In_Time / (Constant.THOUSAND * Constant.SIXTY)) % Constant.SIXTY;
                long difference_In_Hours = (difference_In_Time / (Constant.THOUSAND * Constant.SIXTY * Constant.SIXTY)) % Constant.TWENTYFOUR;
                long total_time = (difference_In_Hours * Constant.SIXTY) + difference_In_Minutes + (difference_In_Seconds / Constant.THIRTY);
                long difference_In_Days = (difference_In_Time / (Constant.THOUSAND * Constant.SIXTY * Constant.SIXTY * Constant.TWENTYFOUR)) % Constant.YEAR;
                if (total_time < Constant.ORDER_DECLINE && total_time >=Constant.ZERO && difference_In_Days == Constant.ZERO) {
                    return true;
                }
            }
        } catch (ParseException e) {
            e.printStackTrace();
            throw new DataNotFoundException();
        }
        return false;
    }


    @Override
    public boolean sendToCart(Order orders) {
        try {
            String kafkaString = objectMapper.writeValueAsString(orders.getUserId());
            kafkaTemplate.send(Constant.KAFKA_TOPIC, UUID.randomUUID().toString(), kafkaString);
            return true;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }


}



