package com.example.OrderModule.Respository;
import com.example.OrderModule.Constant.Constant;
import com.example.OrderModule.model.Order;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;

import java.util.List;


public interface OrderRepository extends MongoRepository<Order,String> {
        @Query(value = Constant.QUERY)
        public Order getOrder(String id);
        public List<Order> findAllByUserId(int id);
}
