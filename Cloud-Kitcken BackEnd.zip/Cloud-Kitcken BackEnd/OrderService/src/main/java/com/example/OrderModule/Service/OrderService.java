package com.example.OrderModule.Service;
import com.example.OrderModule.customException.DataNotFoundException;
import com.example.OrderModule.model.Order;
import com.example.OrderModule.model.OrderDto;
import java.util.List;





public interface OrderService {

     boolean addToOrder(List<Order> orders) ;
     List<OrderDto> getOrder() throws DataNotFoundException ;
     Order getOrderById(String id) throws DataNotFoundException;
     List<OrderDto> getAllOrderOfId(int id) throws DataNotFoundException;
     String placeOrderDB(Order order);
     boolean cancelOrder(String str) throws DataNotFoundException;
     boolean orderDelivered(String str) throws DataNotFoundException;
     boolean checkForOrderStatus(String id,String str) throws DataNotFoundException;
     boolean sendToCart(Order orders);

}
