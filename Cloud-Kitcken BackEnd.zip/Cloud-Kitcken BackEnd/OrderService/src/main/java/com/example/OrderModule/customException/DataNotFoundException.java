package com.example.OrderModule.customException;

import com.example.OrderModule.Constant.Constant;

public class DataNotFoundException extends Exception {
    public DataNotFoundException()
    {
        super(Constant.DATANOTFOUND);
    }

}
