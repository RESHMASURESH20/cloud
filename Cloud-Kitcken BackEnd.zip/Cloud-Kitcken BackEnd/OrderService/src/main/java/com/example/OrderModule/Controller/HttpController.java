package com.example.OrderModule.Controller;
import com.example.OrderModule.Constant.Constant;
import com.example.OrderModule.Service.OrderService;
import com.example.OrderModule.customException.DataNotFoundException;
import com.example.OrderModule.model.Order;
import com.example.OrderModule.model.OrderDto;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;
import java.util.List;



@RestController
@RequestMapping(Constant.ORDERS)
@CrossOrigin("*")
public class HttpController {

    @Autowired
    OrderService orderService;

    @PostMapping(Constant.PLACEORDER)
    public String placeOrder(@RequestBody Order order) throws Exception {
        try {
            return orderService.placeOrderDB(order);
        } catch (Exception e) {
            throw new Exception(e.getMessage());
        }
    }



    @PostMapping(Constant.ADDTOORDER)
    public ResponseEntity<Order> addToOrder(@RequestBody List<Order> Orders) throws Exception {
        if(orderService.addToOrder(Orders))
            return new ResponseEntity<>(HttpStatus.OK);
        else
            return new ResponseEntity<>(HttpStatus.CONFLICT);

    }


    @GetMapping(Constant.GETORDER)
    public List<OrderDto> getOrder() throws Exception {
        try {
            return orderService.getOrder();
        } catch (Exception e) {
            throw new Exception(e.getMessage());
        }
    }



    @GetMapping(Constant.GETORDERBYID)
    public Order getOrderByUserId(@PathVariable() String id) throws DataNotFoundException {
        try {
            return orderService.getOrderById(id);
        } catch (DataNotFoundException e) {
            throw new ResponseStatusException(HttpStatus.CONFLICT, e.getMessage());
        }
    }


    @GetMapping(Constant.GETALLORDERBYID)
    public List<OrderDto> getAllOrderByUserId(@PathVariable() int id) throws DataNotFoundException {
        try {
            return orderService.getAllOrderOfId(id);
        } catch (DataNotFoundException e) {
            throw new ResponseStatusException(HttpStatus.CONFLICT, e.getMessage());
        }
    }


    @PostMapping(Constant.CHECKFORSTATUS)
    public boolean checkForStatus(@PathVariable(Constant.ID) String id, @RequestParam(Constant.STR) String str) {
        try {
            if (orderService.checkForOrderStatus(id, str))
                return true;
            return false;
        } catch (DataNotFoundException e) {
            e.printStackTrace();
            return false;
        }
    }

    @PostMapping(Constant.CANCELORDER)
    public ResponseEntity<?> cancelOrder(@PathVariable String str) {
        try {
            if (orderService.cancelOrder(str))
                return new ResponseEntity<>(HttpStatus.OK);
        } catch (DataNotFoundException e) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, e.getMessage());
        }
        return new ResponseEntity<>(HttpStatus.CONFLICT);
    }

    @PostMapping(Constant.ORDERDELIVERED)
    public ResponseEntity<?> orderDelivered(@PathVariable String str) {
        try {
            if (orderService.orderDelivered(str))
                return new ResponseEntity<>(HttpStatus.OK);
        } catch (DataNotFoundException e) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, e.getMessage());
        }
        return new
                ResponseEntity<>(HttpStatus.CONFLICT);
    }
}

