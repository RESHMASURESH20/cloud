package com.example.OrderModule.model;

import com.example.OrderModule.Constant.Constant;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.format.annotation.DateTimeFormat;

import java.util.Date;
import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString
@Document(collection=Constant.ORDERTABLE)


public class Order {
    @Id
    private String orderId;
    private int userId;
    private String name;
    private String userName;
    private String phonenumber;
    private String alternativenumber;
    private String totalprice;
    private String netprice;
    private String date;
    @DateTimeFormat(iso=DateTimeFormat.ISO.TIME)
    private Date Orderdate=new Date();
    private Date DeclineTime;
    private String status;
    private List<Product> product;

}
