package com.example.AdminService.services;

import com.example.AdminService.CustomException.ProductDataNotFoundException;
import com.example.AdminService.model.Inventory;
import com.example.AdminService.model.InventoryDto;
import com.example.AdminService.model.Order;
import com.example.AdminService.model.ProductDetails;

import java.util.List;
import java.util.Optional;

public interface InventoryService {

     List<InventoryDto> getAllList() throws ProductDataNotFoundException;
     boolean addItems(Inventory foodItems);
     boolean addAllItems(List<Inventory> inventoryList) throws Exception;
     Optional<InventoryDto> getById(int id) throws ProductDataNotFoundException;
     boolean updateById(Inventory inventory) throws ProductDataNotFoundException;
     boolean deleteById(int id) throws Exception;

     List<InventoryDto> getProductByCategory(String str)throws ProductDataNotFoundException;
     List<InventoryDto> searchByName(String query);
     ProductDetails getProductById(int id) throws ProductDataNotFoundException;
}
