package com.example.AdminService.controller;
import com.example.AdminService.Constant.Constant;
import com.example.AdminService.CustomException.ProductDataNotFoundException;
import com.example.AdminService.model.*;
import com.example.AdminService.services.InventoryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;
import java.util.List;
import java.util.Optional;


@RestController
@CrossOrigin("*")
@RequestMapping(Constant.ADMIN)

public class AdminController {
    @Autowired
    InventoryService inventoryService;


    @GetMapping(Constant.GETALL)
    public List<InventoryDto> getAllItems() {
        try {
            return inventoryService.getAllList();
        } catch (ProductDataNotFoundException e) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, e.getMessage());
        }
    }


    @PostMapping(Constant.INSERT)
    public ResponseEntity<InventoryDto> insertFood(@RequestBody Inventory inventory) {
        if (inventoryService.addItems(inventory))
            return new ResponseEntity<>(HttpStatus.CREATED);
        return new ResponseEntity<>(HttpStatus.CONFLICT);


    }


    @GetMapping(Constant.CATEGORY)
    public List<InventoryDto> getByCategory(@PathVariable(Constant.NAME) String name) {
        try {
            return inventoryService.getProductByCategory(name);
        } catch (ProductDataNotFoundException e) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, e.getMessage());
        }

    }


    @PostMapping(Constant.INSERTALL)
    public ResponseEntity<InventoryDto> insertAllFood(@RequestBody List<Inventory> inventory) {
        try {
            if (inventoryService.addAllItems(inventory))
                return new ResponseEntity<>(HttpStatus.CREATED);
        } catch (Exception e) {
            throw new ResponseStatusException(HttpStatus.CONFLICT);
        }
        return new ResponseEntity<>(HttpStatus.CONFLICT);
    }


    @DeleteMapping(Constant.DELETEBYID)
    public ResponseEntity<InventoryDto> deleteById(@PathVariable(Constant.ID) int id) throws Exception {
        try {
            if (inventoryService.deleteById(id))
                return new ResponseEntity<>(HttpStatus.OK);
        } catch (ProductDataNotFoundException e) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, e.getMessage());
        }
        return new ResponseEntity<>(HttpStatus.CONFLICT);
    }


    @GetMapping(Constant.GETBYID)
    public Optional<InventoryDto> getById(@PathVariable(Constant.ID) int id) {
        try {
            System.out.println(inventoryService.getById(id).toString());
            return inventoryService.getById(id);
        } catch (ProductDataNotFoundException e) {
            throw new ResponseStatusException(HttpStatus.CONFLICT, e.getMessage());
        }
    }

    @GetMapping(Constant.SEARCH)
    public List<InventoryDto> searchProductByName(@RequestParam String name) {
        try {
            return inventoryService.searchByName(name);
        } catch (Exception e) {
//            e.printStackTrace();
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, e.getMessage());
        }
    }

    @PutMapping(Constant.UPDATEBYID)
    public ResponseEntity<InventoryDto> updateById(@RequestBody Inventory inventory) {
        try {
            if (inventoryService.updateById(inventory))
                return new ResponseEntity<>(HttpStatus.OK);
        } catch (ProductDataNotFoundException e) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, e.getMessage());
        }
        return new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }

    @GetMapping(Constant.GETBYPRODUCTID)
    public ProductDetails getProductById(@PathVariable(Constant.ID) int id) {
        try {
            return inventoryService.getProductById(id);
        } catch (ProductDataNotFoundException e) {
            throw new ResponseStatusException(HttpStatus.CONFLICT);
        }

    }

}
