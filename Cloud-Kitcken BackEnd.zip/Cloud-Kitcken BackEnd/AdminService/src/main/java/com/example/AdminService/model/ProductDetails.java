package com.example.AdminService.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class ProductDetails {
    private String productname;
    private String price;
    private String imageurl;
    private String existingquantity;
    private int offer;
}
