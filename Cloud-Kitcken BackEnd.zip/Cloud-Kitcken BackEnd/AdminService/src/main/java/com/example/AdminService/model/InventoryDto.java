package com.example.AdminService.model;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class InventoryDto {

    private int foodId;
    private String foodname;
    private String price;
    private String  stockCount;
    private String category;
    private String cuisine;
    private String description;
    private int offer;
    private String url;

}