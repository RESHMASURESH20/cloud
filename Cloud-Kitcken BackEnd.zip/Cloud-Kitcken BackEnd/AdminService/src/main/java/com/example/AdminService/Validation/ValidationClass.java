package com.example.AdminService.Validation;

import com.example.AdminService.model.Inventory;
import com.example.AdminService.model.InventoryDto;

import java.util.Objects;

public class ValidationClass {

    public static boolean  ProductValidation(Inventory inventory)
    {
        if(!Objects.isNull(inventory.getFoodname())
                &&!Objects.isNull(inventory.getCategory())
                &&!Objects.isNull(inventory.getCuisine())
                &&!Objects.isNull(inventory.getDescription())
                &&!Objects.isNull(inventory.getOffer())
                &&(!Objects.isNull(inventory.getStockCount()))
                &&!Objects.isNull(inventory.getUrl())
                &&!Objects.isNull(inventory.getPrice()))
        {
            return true;
        }
        else return false;
    }
}
