package com.example.AdminService.exception;

public class AdminException extends Exception {
    public AdminException(String message){super(message);}
}
