package com.example.AdminService.serviceImplementation;

import com.example.AdminService.Constant.Constant;
import com.example.AdminService.CustomException.ProductDataNotFoundException;
import com.example.AdminService.Repository.InventoryRepositoy;
import com.example.AdminService.Validation.ValidationClass;
import com.example.AdminService.model.*;
import com.example.AdminService.services.InventoryService;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.dao.DataAccessException;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.server.ResponseStatusException;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;


@Service
@Component
public class InventroyServiceImplementation implements InventoryService {

    @Autowired
    InventoryRepositoy inventoryRepositoy;


    private RestTemplate restTemplate;

    public InventroyServiceImplementation(RestTemplateBuilder restTemplateBuilder) {

        restTemplate = restTemplateBuilder.build();
    }


    private void clearRedis(int productId) {
        restTemplate.delete(Constant.URL_REDIS + productId + "", productId, String.class);
    }

    public InventoryDto entityToDto(Inventory inventory) {
        InventoryDto inventoryDto = new InventoryDto();
        inventoryDto.setCategory(inventory.getCategory());
        inventoryDto.setCuisine(inventory.getCuisine());
        inventoryDto.setDescription(inventory.getDescription());
        inventoryDto.setFoodId(inventory.getFoodId());
        inventoryDto.setOffer(inventory.getOffer());
        inventoryDto.setPrice(inventory.getPrice());
        inventoryDto.setStockCount(inventory.getStockCount());
        return inventoryDto;

    }


    @Override
    public List<InventoryDto> getAllList() throws ProductDataNotFoundException {
        try {
            Iterable<Inventory> iterable = inventoryRepositoy.findAll();
            List<InventoryDto> inventoryDtoList = StreamSupport.stream(iterable.spliterator(), false).map(inventory -> {
                InventoryDto dto = new InventoryDto();
                BeanUtils.copyProperties(inventory, dto);
                return dto;
            }).collect(Collectors.toList());
            return inventoryDtoList;
        } catch (Exception e) {
            throw new ProductDataNotFoundException();
        }
    }


    @Override
    public boolean addItems(Inventory foodItem) {

        try {
            if (ValidationClass.ProductValidation(foodItem)) {
                if (Objects.isNull(inventoryRepositoy.getByFoodId(foodItem.getFoodId()))) {
                    inventoryRepositoy.save(foodItem);
                    clearRedis(foodItem.getFoodId());
                    return true;
                }
            } else {
                System.out.println(foodItem.toString());
                return false;
            }
        } catch (DataAccessException e) {
            e.printStackTrace();
        }
        return false;
    }

    @Override
    public boolean addAllItems(List<Inventory> inventoryList) throws Exception {
        try {
            inventoryRepositoy.saveAll(inventoryList);
            return true;
        } catch (Exception e) {
            throw new ResponseStatusException(HttpStatus.CONFLICT);
        }
    }


    @Override
    public Optional<InventoryDto> getById(int id) throws ProductDataNotFoundException {
        try {
            return inventoryRepositoy.findById(id).map(this::entityToDto);
        } catch (Exception e) {
            throw new ProductDataNotFoundException();
        }
    }

    @Override
    public boolean updateById(Inventory inventory) throws ProductDataNotFoundException {
        try {
            if (!Objects.isNull(inventoryRepositoy.getByFoodId(inventory.getFoodId()))) {
                inventoryRepositoy.save(inventory);
                clearRedis(inventory.getFoodId());
                return true;
            }
        } catch (DataAccessException e) {
            throw new ProductDataNotFoundException();
        }
        return false;
    }

    @Override
    public boolean deleteById(int id) throws Exception {
        try {
            if (!Objects.isNull(inventoryRepositoy.getByFoodId(id))) {
                clearRedis(inventoryRepositoy.getByFoodId(id).getFoodId());
                inventoryRepositoy.deleteById(id);
                return true;
            }
        } catch (DataAccessException e) {
            throw new ProductDataNotFoundException();
        }
        return false;

    }


    @Override
    public List<InventoryDto> searchByName(String query) {
        List<InventoryDto> inventoryDtoList = new ArrayList<>();
        InventoryDto inventoryDto;
        System.out.println(inventoryRepositoy.findAllByFoodnameContainingIgnoreCase(query).toString());
        for (Inventory inventory : inventoryRepositoy.findAllByFoodnameContainingIgnoreCase(query)) {
            inventoryDto = entityToDto(inventory);
            inventoryDto.setFoodname(inventory.getFoodname());
            inventoryDto.setUrl(inventory.getUrl());
            inventoryDtoList.add(inventoryDto);
        }
        return inventoryDtoList;
    }

    @Override
    public List<InventoryDto> getProductByCategory(String str) throws ProductDataNotFoundException

    {
        try {
            if (Objects.isNull(inventoryRepositoy.getAllBycategory(str))) {
                throw new ProductDataNotFoundException();
            } else {
                List<InventoryDto> inventoryDtoList = new ArrayList<>();
                InventoryDto inventoryDto;
                System.out.println(inventoryRepositoy.getAllBycategory(str).toString());
                for (Inventory inventory : inventoryRepositoy.getAllBycategory(str)) {
                    inventoryDto = entityToDto(inventory);
                    inventoryDto.setFoodname(inventory.getFoodname());
                    inventoryDto.setUrl(inventory.getUrl());
                    inventoryDtoList.add(inventoryDto);
                }
                return inventoryDtoList;
            }
        } catch (ProductDataNotFoundException e) {
            throw new ProductDataNotFoundException();
        }
    }


    @Override
    public ProductDetails getProductById(int id) throws ProductDataNotFoundException {
        try {
            ProductDetails productDetails = new ProductDetails();
            productDetails.setPrice(inventoryRepositoy.getByFoodId(id).getPrice());
            productDetails.setImageurl(inventoryRepositoy.getByFoodId(id).getUrl());
            productDetails.setProductname(inventoryRepositoy.getByFoodId(id).getFoodname());
            productDetails.setExistingquantity(inventoryRepositoy.getByFoodId(id).getStockCount());
            productDetails.setOffer(inventoryRepositoy.getByFoodId(id).getOffer());
            return productDetails;
        } catch (Exception e) {
            throw new ProductDataNotFoundException();
        }
    }


}

//    @Override
//    public String decrementStock(Order order) {
//        try{
//            System.out.println("inside decrement");
//            System.out.println(order.toString());
//            if(order == null)
//                throw new ProductDataNotFoundException();
//            List<Product> products = order.getProduct();
//            Iterator<Product> it = products.iterator();
//            while (it.hasNext()){
//                Product product = it.next();
//                System.out.println(inventoryRepositoy.getByFoodId(product.getProductid()).toString());
//                Inventory inventory=inventoryRepositoy.getByFoodId(product.getProductid());
//                inventory.setStockCount(inventory.getStockCount()-product.getQuantity());
//                inventoryRepositoy.save(inventory);
//                System.out.println(inventoryRepositoy.getByFoodId(product.getProductid()).toString());
//            }
//            return "success";
//
//        }catch (ProductDataNotFoundException e){
//            e.printStackTrace();
//        }
//        return "no";
//    }

//    @Override
//    public String incrementStock(Order order) {
//        try{
//            System.out.println("inside increment");
//            System.out.println(order.toString());
//            if(order == null)
//                throw new ProductDataNotFoundException();
//            List<Product> products = order.getProduct();
//            Iterator<Product> it = products.iterator();
//            while (it.hasNext()){
//                Product product = it.next();
//                System.out.println(inventoryRepositoy.getByFoodId(product.getProductid()).toString());
//                Inventory inventory=inventoryRepositoy.getByFoodId(product.getProductid());
//                inventory.setStockCount(inventory.getStockCount()+product.getQuantity());
//                inventoryRepositoy.save(inventory);
//                System.out.println(inventoryRepositoy.getByFoodId(product.getProductid()).toString());
//            }
//            return "success";
//
//        }catch (ProductDataNotFoundException e){
//            e.printStackTrace();
//        }
//        return "no";
//    }
//}

