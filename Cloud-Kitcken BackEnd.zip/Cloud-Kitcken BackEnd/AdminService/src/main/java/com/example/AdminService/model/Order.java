package com.example.AdminService.model;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import java.util.List;
@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class Order {
    private String orderId;
    private int userId;
    private String name;
    private String userName;
    private String phonenumber;
    private String alternativenumber;
    private String totalprice;
    private String netprice;
    private String date;
    private String status;
    private List<Product> product;
}
