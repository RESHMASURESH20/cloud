package com.example.AdminService.Repository;

import com.example.AdminService.model.Inventory;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface InventoryRepositoy extends CrudRepository<Inventory,Integer> {
     Inventory getByFoodId(int productId);
     List<Inventory> getAllBycategory(String str);
    List<Inventory> findAllByFoodnameContainingIgnoreCase(String query);



}
