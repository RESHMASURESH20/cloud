package com.example.AdminService.Constant;

public interface Constant {
    String ADMIN = "/admin";
    String GETALL = "/getAll";
    String INSERT = "/insert";
    String CATEGORY = "/category/{name}";
    String INSERTALL = "/insertAll";
    String DELETEBYID = "/deleteById/{id}";
    String GETBYID = "/getById/{id}";
    String SEARCH = "/search";
    String UPDATEBYID = "/updateById";
    String GETBYPRODUCTID = "/getByproductId/{id}";
    String ID = "id";
    String PRODUCTNOTFOUND = "ProductDetails data not found";
    String NAME = "name";
    String INVENTORYTABLE = "inventory";
    String FOODID = "foodid";
    String FOODNAME = "foodname";
    String STOCKCOUNT = "stockcount";
    String PRICE = "price";
    String CATEGORYS = "category";
    String CUISINE = "cuisine";
    String DESCRIPTION = "description";
    String OFFER = "offer";
    String URL = "url";
    String URL_REDIS = "http://localhost:8898/cart/removeRedis/";
//String URL_REDIS="http://10.30.1.86:8898/cart/removeRedis/";

}

