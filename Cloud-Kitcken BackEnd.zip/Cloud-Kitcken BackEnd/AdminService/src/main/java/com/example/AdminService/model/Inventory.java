package com.example.AdminService.model;

import com.example.AdminService.Constant.Constant;
import com.sun.istack.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = Constant.INVENTORYTABLE)
@Data
@ToString
@AllArgsConstructor
@NoArgsConstructor
public class  Inventory {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = Constant.FOODID)
    private int foodId;
    @NotNull
    @Column(name = Constant.FOODNAME)
    private String foodname;
    @NotNull
    @Column(name = Constant.PRICE)
    private String price;
    @NotNull
    @Column(name = Constant.STOCKCOUNT)
    private String stockCount;
    @NotNull
    @Column(name = Constant.CATEGORYS)
    private String category;
    @NotNull
    @Column(name = Constant.CUISINE)
    private String cuisine;
    @NotNull
    @Column(name = Constant.DESCRIPTION)
    private String description;
    @NotNull
    @Column(name = Constant.OFFER)
    private int offer;
    @NotNull
    @Column(name = Constant.URL)
    private String url;
}
