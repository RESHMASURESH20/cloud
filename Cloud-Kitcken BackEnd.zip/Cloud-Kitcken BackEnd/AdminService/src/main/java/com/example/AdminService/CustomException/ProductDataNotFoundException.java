package com.example.AdminService.CustomException;

import com.example.AdminService.Constant.Constant;

public class ProductDataNotFoundException extends Exception {
    public ProductDataNotFoundException()
    {

        super(Constant.PRODUCTNOTFOUND);
    }
}
