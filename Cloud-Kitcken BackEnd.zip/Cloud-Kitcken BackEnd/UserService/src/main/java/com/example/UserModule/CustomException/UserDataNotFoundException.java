package com.example.UserModule.CustomException;

import com.example.UserModule.Constant.Constant;

public class UserDataNotFoundException extends Exception {

    public String getMessage() {
        return Constant.USERNOTFOUND;
    }

}