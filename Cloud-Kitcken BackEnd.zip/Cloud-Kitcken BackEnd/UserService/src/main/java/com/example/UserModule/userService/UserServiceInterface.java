package com.example.UserModule.userService;

import com.example.UserModule.CustomException.UserDataNotFoundException;
import com.example.UserModule.model.Authenticate;
import com.example.UserModule.model.User;
import com.example.UserModule.modelDto.UserDto;

import java.util.List;

public interface UserServiceInterface {
     boolean createUser(User user);

     boolean validateUser(Authenticate authenticate);

     boolean updateUser(User user) throws UserDataNotFoundException;

     boolean deleteUser(int userId) throws UserDataNotFoundException;

     List<UserDto> getAllUserDetails() throws UserDataNotFoundException;

     UserDto getUserByMail(String emailId) throws UserDataNotFoundException;

     User getUserId(String name);
}
