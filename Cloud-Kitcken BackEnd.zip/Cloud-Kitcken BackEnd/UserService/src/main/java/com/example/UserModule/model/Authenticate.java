package com.example.UserModule.model;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class Authenticate {
    String loginPassword;
    String userType;
    String userName;
    String email;

}