package com.example.UserModule.model;

import com.example.UserModule.Constant.Constant;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Entity
@Table(name =Constant.USER_DETAILS_TABLE)
public class User {
    @Id
    @Column(name = Constant.USERID)
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int userId;
    @Column(name = Constant.USERNAME)
    private String userName;
    @Column(name = Constant.NAME)
    private String name;
    @Column(name =Constant.PHONENO)
    private String phoneNo;
    @Column(name = Constant.EMAIL)
    private String email;
    @Column(name =Constant.ADDRESS)
    private String address;
    @Column(name =Constant.USERTYPE)
    private String userType;
    @Column(name = Constant.LOGINPASSWORD)
    private String loginPassword;

}
