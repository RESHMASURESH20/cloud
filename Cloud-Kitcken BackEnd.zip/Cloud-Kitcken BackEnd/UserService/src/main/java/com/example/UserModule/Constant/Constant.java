package com.example.UserModule.Constant;

public interface Constant {
    String CREATEUSER="/createUser";
    String VALIDATEUSER="/validateUser";
    String UPDATEUSER="/updateUser";
    String DELETE_USER="/deleteUser/{userId}";
    String ALL_USER_DETAILS="/allUserDetails";
    String GET_USERBY_MAIL="/getUserByMail/emailId";
    String GET_USERID="/getUserId/name";
    String  USER_DETAILS_TABLE="userdetails";
    String USERID="userid";
    String USERNAME="username";
    String NAME="name";
    String  PHONENO="phoneno";
    String EMAIL="email";
    String  ADDRESS="address";
    String  USERTYPE="usertype";
    String LOGINPASSWORD="loginpassword";
    String SHA="SHA-1";
    String CUSTOMER="Customer";
    String ADMIN="admin";
    String USERNOTFOUND="User Data not found";
}
