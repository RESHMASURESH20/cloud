package com.example.UserModule.modelDto;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@NoArgsConstructor
@AllArgsConstructor
@ToString
@Data
public class UserDto {

    private int userId;
    private String userName;
    private String phoneNo;
    private String email;
    private String address;
    private String userType;
    private String loginPassword;
}
