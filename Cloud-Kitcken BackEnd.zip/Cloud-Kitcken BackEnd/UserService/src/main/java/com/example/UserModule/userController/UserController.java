package com.example.UserModule.userController;

import com.example.UserModule.Constant.Constant;
import com.example.UserModule.CustomException.UserDataNotFoundException;
import com.example.UserModule.model.Authenticate;
import com.example.UserModule.model.User;
import com.example.UserModule.modelDto.UserDto;
import com.example.UserModule.userService.UserServiceInterface;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;

@RestController
@CrossOrigin("*")
public class UserController {
    @Autowired
    UserServiceInterface userServiceInterface;


    @PostMapping(Constant.CREATEUSER)
    public ResponseEntity<UserDto> createUser(@RequestBody User user) {
        System.out.println(user.toString());
        if (userServiceInterface.createUser(user))
            return new ResponseEntity<>(HttpStatus.CREATED);
        return new ResponseEntity<>(HttpStatus.CONFLICT);
    }


    @PostMapping(Constant.VALIDATEUSER)
    public boolean validateUser(@RequestBody Authenticate authenticate) {
        boolean validate = false;
        try {
            validate = userServiceInterface.validateUser(authenticate);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return validate;
    }


    @PostMapping(Constant.UPDATEUSER)
    public ResponseEntity<UserDto> updateUser(@RequestBody User user) {
        try {
            if (userServiceInterface.updateUser(user))
                return new ResponseEntity<>(HttpStatus.OK);

        } catch (UserDataNotFoundException e) {
            System.out.println(e.getMessage());
        }
        return new ResponseEntity<>(HttpStatus.CONFLICT);
    }


    @GetMapping(Constant.DELETE_USER)
    public ResponseEntity<UserDto> deleteUser(int userId) {
        try {
            if (userServiceInterface.deleteUser(userId))
                return new ResponseEntity<>(HttpStatus.OK);
        } catch (UserDataNotFoundException e) {
            System.out.println(e.getMessage());
        }
        return new ResponseEntity<>(HttpStatus.CONFLICT);
    }


    @GetMapping(Constant.ALL_USER_DETAILS)
    public List<UserDto> getAllUser() {
        try {
            return userServiceInterface.getAllUserDetails();
        } catch (UserDataNotFoundException e) {
            System.out.println(e.getMessage());
        }
        return null;
    }


    @GetMapping(Constant.GET_USERBY_MAIL)
    public UserDto getUserByMail(@RequestParam String emailId) {
        try {
            return userServiceInterface.getUserByMail(emailId);
        } catch (Exception e) {
            throw new ResponseStatusException(HttpStatus.CONFLICT, e.getMessage());
        }
    }


    @GetMapping(Constant.GET_USERID)
    public User getUserId(@RequestParam String name)
    {
        return userServiceInterface.getUserId(name);
    }
}
