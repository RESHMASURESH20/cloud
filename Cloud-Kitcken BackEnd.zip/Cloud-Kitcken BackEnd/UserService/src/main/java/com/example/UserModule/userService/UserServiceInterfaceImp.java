package com.example.UserModule.userService;

import com.example.UserModule.Constant.Constant;
import com.example.UserModule.CustomException.UserDataNotFoundException;
import com.example.UserModule.model.Authenticate;
import com.example.UserModule.model.User;
import com.example.UserModule.modelDto.UserDto;
import com.example.UserModule.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import javax.transaction.Transactional;
import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

@Service
public class UserServiceInterfaceImp implements UserServiceInterface {

    @Autowired
    UserRepository userRepository;

    @Value("${spring.adminId}")
    private String adminId;
    @Value("${spring.adminPassword}")
    private String adminPassword;

    public static String encryption(String loginPassword) {
        try {
            MessageDigest md = MessageDigest.getInstance(Constant.SHA);
            byte[] messageDigest = md.digest(loginPassword.getBytes());
            BigInteger no = new BigInteger(1, messageDigest);
            String hashtext = no.toString(16);
            while (hashtext.length() < 32) {
                hashtext = "0" + hashtext;
            }
            return hashtext;
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public boolean createUser(User user) {
        String hashtext = UserServiceInterfaceImp.encryption(user.getLoginPassword());
        user.setLoginPassword(hashtext);
        try {
            if (Objects.isNull(userRepository.findByUserName(user.getUserName()))) {
                userRepository.save(user);
                return true;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    @Override
    public boolean validateUser(Authenticate authenticate) {
        String loginPassword = authenticate.getLoginPassword();
        String userType = authenticate.getUserType();
        String userName = authenticate.getUserName();

        if (userType.equalsIgnoreCase(Constant.CUSTOMER)) {

            try {

                if (!Objects.isNull(userRepository.findByUserName(userName))) {
                    User user = userRepository.findByUserName(userName);
                    String hashtext = UserServiceInterfaceImp.encryption(loginPassword);
                    if (hashtext.equals(user.getLoginPassword())) {
                        return true;
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
                return false;
            }
        } else if (userType.equalsIgnoreCase(Constant.ADMIN)) {
            if (loginPassword.equals(adminPassword) && userName.equals(adminId)) {
                return true;
            }
        }
        return false;


    }

    @Override
    public boolean updateUser(User user) throws UserDataNotFoundException {

        String hashtext = UserServiceInterfaceImp.encryption(user.getLoginPassword());
        user.setLoginPassword(hashtext);
        try {
            if (!Objects.isNull(userRepository.findByUserName(user.getUserName()))) {
                userRepository.save(user);
                return true;
            }
        } catch (Exception e) {
            e.printStackTrace();
            throw new UserDataNotFoundException();
        }
        return false;
    }

    @Override
    @Transactional
    public boolean deleteUser(int userId) throws UserDataNotFoundException {
        try {
            if (!Objects.isNull(userRepository.findByUserId(userId))) {
                userRepository.deleteByUserId(userId);
                return true;
            }
        } catch (Exception e) {
            e.printStackTrace();
            throw new UserDataNotFoundException();
        }
        return false;
    }

    @Override
    public List<UserDto> getAllUserDetails() throws UserDataNotFoundException {
        try {
            return userRepository.findAll().stream().map(this::modelToDto).collect(Collectors.toList());
        } catch (Exception e) {
            e.printStackTrace();
            throw new UserDataNotFoundException();
        }
    }

    public UserDto modelToDto(User user) {
        UserDto userDto = new UserDto();
        userDto.setUserId(user.getUserId());
        userDto.setAddress(user.getAddress());
        userDto.setEmail(user.getEmail());
        userDto.setLoginPassword(user.getLoginPassword());
        userDto.setPhoneNo(user.getPhoneNo());
        userDto.setUserType(user.getUserType());

        return userDto;
    }


    @Override
    public UserDto getUserByMail(String emailId) throws UserDataNotFoundException {
        try {
            UserDto userDto = modelToDto(userRepository.findByEmail(emailId));
            return userDto;
        } catch (Exception e) {
            throw new UserDataNotFoundException();
        }
    }

    @Override
    public User getUserId(String name) {
        return userRepository.findByUserName(name);
    }
}
