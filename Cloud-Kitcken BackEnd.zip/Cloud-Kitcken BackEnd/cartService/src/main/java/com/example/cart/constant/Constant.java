package com.example.cart.constant;

public interface Constant {

//    String URL = "http://10.30.1.159:8888/admin/getByproductId/";
String URL = "http://localhost:8888/admin/getByproductId/";
    String CART = "/cart";
    String ADDTOCART = "/add";
    String GETCART  = "/getCart";
    String GETCARTBYID = "/getCartByUserid/{userid}";
    String INCREMENTQUANTITY = "/increment/{userid}/{productid}";
    String DECREMENTQUANTITY = "/decrement/{userid}/{productid}";
    String DELETEPRODUCT = "/delete/{userid}/{productid}";
    String DELETECARTBYID = "/deleteCartItem/{id}";
    String REDISSAVE = "/saveRedis";
    String REDISGETALL= "/getAllRedis";
    String REDISGETBYID= "/getByIdRedis/{id}";
    String REDISREMOVEBYID = "/removeRedis/{id}";
    String REDISSEARCHBYID ="/search/{id}";
    String EXCEPTIONINADD ="Could'nt add to cart.";
    String EXCEPTIONINGETPRODUCT ="Could'nt get products from cart.";
    String EXCEPTIONINGETCART = "Could'nt get cart from user";
    String EXCEPTIONNOUSERFOUND = "No user found.";
    String EXCEPTIONININCREMENT = "Could'nt increment";
    String EXCEPTIONINDECREMENT = "Could'nt decrement";
    String EXCEPTIONINDELETE = "Could'nt delete";


}
