package com.example.cart.controller;


import com.example.cart.constant.Constant;
import com.example.cart.exception.CartException;
import com.example.cart.model.Cart;
import com.example.cart.model.CartDto;
import com.example.cart.redisEntity.ProductId;
import com.example.cart.repository.RedisRepository;
import com.example.cart.service.CartService;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping(Constant.CART)
@CrossOrigin("*")
public class Controller {

    @Autowired
    CartService cartService;

    public static final org.slf4j.Logger LOGGER = LoggerFactory.getLogger(String.class);


//    @PostMapping("/addToCart")
//    public List<Cart> addToCart(@RequestBody List<Cart> carts) throws CartException{
//        try {
//            cartService.addToCart(carts);
//        }catch (CartException e){
//            throw new CartException(e.getMessage());
//        }
//        return carts;
//    }

    @PostMapping(Constant.ADDTOCART)
    public ResponseEntity<?> add(@RequestBody Cart cart) throws CartException{
        try {
            LOGGER.info("added to cart");
             cartService.add(cart);
            return new ResponseEntity<>(HttpStatus.OK);
        }catch (Exception e){
            return new ResponseEntity<>(HttpStatus.CONFLICT);
        }
    }


    @GetMapping(Constant.GETCART)
    public List<CartDto> getCart() throws CartException{
        try {
            return cartService.getCart();
        }catch (CartException e){
            throw new CartException(e.getMessage());
        }
    }


    @GetMapping(Constant.GETCARTBYID)
    public CartDto getCartByUserid(@PathVariable int userid) throws CartException{
        try {
            LOGGER.info("getCartByUserid");
            return cartService.getCartByUseridAsDto(userid);
        }catch (CartException e){
            throw new CartException(e.getMessage());
        }
    }

    @PutMapping(Constant.INCREMENTQUANTITY)
    public void incrementQuantity(@PathVariable("userid") int userid,@PathVariable("productid") int productid) throws CartException{
        try{
            LOGGER.info("incrementQuantity");
             cartService.increment(userid,productid);
        }catch (CartException e){
            throw new CartException(e.getMessage());
        }
    }

    @PutMapping(Constant.DECREMENTQUANTITY)
    public Cart decrementQuantity(@PathVariable("userid") int userid,@PathVariable("productid") int productid) throws CartException{
        try{
            LOGGER.info("decrementQuantity");
            return cartService.decrement(userid,productid);
        }catch (CartException e){
            throw new CartException(e.getMessage());
        }
    }

    @DeleteMapping(Constant.DELETEPRODUCT)
    public void delete(@PathVariable("userid") int userid,@PathVariable("productid") int productid) throws CartException{
        try{
            LOGGER.info("deleted product from cart");
            cartService.delete(userid,productid);
        }catch (CartException e){
            throw new CartException(e.getMessage());
        }
    }

    @DeleteMapping(Constant.DELETECARTBYID)
    public String deleteCartItem(@PathVariable("id")int id) throws CartException {
        try {
            LOGGER.info("deletedCart");
            cartService.deleteCartItem(id);
        }catch (CartException e){
            throw new CartException(e.getMessage());
        }
        return "deleted";
    }

    @Autowired
    RedisRepository redisRepository;

    @PostMapping(Constant.REDISSAVE)
    public ProductId save(@RequestBody ProductId productId){
        redisRepository.save(productId);
        LOGGER.info("saved in redis");
        return  productId;

    }

    @GetMapping(Constant.REDISGETALL)
    public List<ProductId> getRedisProduct(){
        LOGGER.info("getall from redis");
        return redisRepository.findAll();
    }

    @GetMapping(Constant.REDISGETBYID)
    public ProductId getByIdRedis(@PathVariable("id") int id){
        LOGGER.info("get by id in redis");
        return redisRepository.findById(id);
    }

    @DeleteMapping(Constant.REDISREMOVEBYID)
    public String removeProductRedis(@PathVariable("id") int id){
        LOGGER.info("removed from redis");
        return redisRepository.deleteById(id);
    }

    @GetMapping(Constant.REDISSEARCHBYID)
    public Boolean searchRedis(@PathVariable("id") int id){
        ProductId productId =  redisRepository.findById(id);
        if(productId == null){
            return false;
        }
        return true;
    }

}
