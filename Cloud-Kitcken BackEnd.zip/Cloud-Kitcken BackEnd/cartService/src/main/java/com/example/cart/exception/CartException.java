package com.example.cart.exception;

public class CartException extends Exception {
    public CartException(String message){super(message);}

}
