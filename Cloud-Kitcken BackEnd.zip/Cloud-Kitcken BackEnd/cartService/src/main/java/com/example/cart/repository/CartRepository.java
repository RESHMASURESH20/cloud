package com.example.cart.repository;

import com.example.cart.model.Cart;
import com.example.cart.model.CartDto;
import com.example.cart.model.Product;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;

import java.util.List;

public interface CartRepository extends MongoRepository<Cart,Integer> {


    @Query(value = "{'userid':?0}")
    public Cart getCart(int id);

//    @Query(value = "{ 'userid':?0, 'products.productid':?1}")
//    public List<Cart> getProduct(int userid,int productid);




}
