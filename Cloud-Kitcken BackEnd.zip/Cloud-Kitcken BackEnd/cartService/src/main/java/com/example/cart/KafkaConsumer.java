package com.example.cart;

import com.example.cart.repository.RedisRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Component;

@Component
public class KafkaConsumer {


    @Autowired
    RedisRepository redisRepository;

    @KafkaListener(containerFactory = "kafkaListenerContainerFactory",topics = "placeOrder",groupId = "group_id")
    public void consume(String message){
        redisRepository.deleteById(Integer.parseInt(message));
    }

}
