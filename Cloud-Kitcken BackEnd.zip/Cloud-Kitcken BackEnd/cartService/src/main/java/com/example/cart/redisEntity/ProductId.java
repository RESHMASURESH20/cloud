package com.example.cart.redisEntity;

import org.springframework.data.annotation.Id;
import org.springframework.data.redis.core.RedisHash;

import java.io.Serializable;


@RedisHash("ProductId1")
public class ProductId implements Serializable {

    @Id
    private int id;
    private String productname;
    private double price;
    private String imageurl;
    private int offer;
    private String existingquantity;

    public ProductId() {
    }

    public ProductId(int id, String productname, double price, String imageurl, int offer, String existingquantity) {
        this.id = id;
        this.productname = productname;
        this.price = price;
        this.imageurl = imageurl;
        this.offer = offer;
        this.existingquantity = existingquantity;
    }

    public String getExistingquantity() {
        return existingquantity;
    }

    public void setExistingquantity(String existingquantity) {
        this.existingquantity = existingquantity;
    }

    public String getProductname() {
        return productname;
    }

    public void setProductname(String productname) {
        this.productname = productname;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public String getImageurl() {
        return imageurl;
    }

    public void setImageurl(String imageurl) {
        this.imageurl = imageurl;
    }

    public int getOffer() {
        return offer;
    }

    public void setOffer(int offer) {
        this.offer = offer;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }
}
