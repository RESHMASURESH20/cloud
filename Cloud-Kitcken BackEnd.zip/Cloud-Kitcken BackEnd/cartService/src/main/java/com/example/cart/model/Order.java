package com.example.cart.model;


import java.util.List;

public class Order {

    private String id;
    private int userId;
    private String name;
    private String userName;
    private String phonenumber;
    private String alternativenumber;
    private String totalprice;
    private String netprice;
    private String date;
    private String status;
    private List<Product> product;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getPhonenumber() {
        return phonenumber;
    }

    public void setPhonenumber(String phonenumber) {
        this.phonenumber = phonenumber;
    }

    public String getAlternativenumber() {
        return alternativenumber;
    }

    public void setAlternativenumber(String alternativenumber) {
        this.alternativenumber = alternativenumber;
    }

    public String getTotalprice() {
        return totalprice;
    }

    public void setTotalprice(String totalprice) {
        this.totalprice = totalprice;
    }

    public String getNetprice() {
        return netprice;
    }

    public void setNetprice(String netprice) {
        this.netprice = netprice;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public List<Product> getProduct() {
        return product;
    }

    public void setProduct(List<Product> product) {
        this.product = product;
    }

    public Order() {
    }

    public Order(String id, int userId, String name, String userName, String phonenumber, String alternativenumber, String totalprice, String netprice, String date, String status, List<Product> product) {
        this.id = id;
        this.userId = userId;
        this.name = name;
        this.userName = userName;
        this.phonenumber = phonenumber;
        this.alternativenumber = alternativenumber;
        this.totalprice = totalprice;
        this.netprice = netprice;
        this.date = date;
        this.status = status;
        this.product = product;
    }

    @Override
    public String toString() {
        return "Order{" +
                "id='" + id + '\'' +
                ", userId=" + userId +
                ", name='" + name + '\'' +
                ", userName='" + userName + '\'' +
                ", phonenumber='" + phonenumber + '\'' +
                ", alternativenumber='" + alternativenumber + '\'' +
                ", totalprice='" + totalprice + '\'' +
                ", netprice='" + netprice + '\'' +
                ", date='" + date + '\'' +
                ", status='" + status + '\'' +
                ", product=" + product +
                '}';
    }
}
