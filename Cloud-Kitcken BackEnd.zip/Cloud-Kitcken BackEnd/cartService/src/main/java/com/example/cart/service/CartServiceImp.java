package com.example.cart.service;

import com.example.cart.constant.Constant;
import com.example.cart.exception.CartException;
import com.example.cart.model.*;
import com.example.cart.redisEntity.ProductId;
import com.example.cart.repository.CartRepository;
import com.example.cart.repository.RedisRepository;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.*;

@Service
public class CartServiceImp implements CartService{

    public static final org.slf4j.Logger LOGGER = LoggerFactory.getLogger(String.class);


    @Autowired
    CartRepository cartRepository;

    @Autowired
    RestTemplate restTemplate;

    @Autowired
    RedisRepository redisRepository;

    public List<Cart> addToCart(List<Cart> carts) throws CartException{
        try {
            cartRepository.saveAll(carts);
        }catch (DataAccessException e){
            e.printStackTrace();
            throw new CartException(Constant.EXCEPTIONINADD);
        }
        return carts;
    }

    public Cart add(Cart cart) throws CartException{
        try {

            Cart existingCart = getCartByUserid(cart.getUserid());

            if(existingCart == null){
                cartRepository.save(cart);
            }else {
                List<Product> existingCartProducts = existingCart.getProducts();

                for(Product product : cart.getProducts()){
                    existingCartProducts.add(product);
                }
                cartRepository.save(existingCart);

            }
            return cart;
        }catch (DataAccessException e){
            throw new CartException(Constant.EXCEPTIONINADD);
        }
    }


    public List<CartDto> getCart() throws CartException{
        try {

            List<CartDto> list = new ArrayList<>();
            for (Cart cart : cartRepository.findAll()) {
                CartDto cartDto = entityToDto(cart);
                list.add(cartDto);
            }
            return list;
        }catch (DataAccessException e){
            throw new CartException(Constant.EXCEPTIONINGETPRODUCT);
        }catch (CartException c){
            throw new CartException(c.getMessage());
        }
    }


    public Cart getCartByUserid(int userid)throws CartException {
        try{
            Cart cart = cartRepository.getCart(userid);

            if(cart == null)
                return null;
            return cart;
        }catch (DataAccessException e){
            throw new CartException(Constant.EXCEPTIONINGETCART);
        }catch (Exception e){
            throw new CartException(e.getMessage());
        }
    }


    public CartDto getCartByUseridAsDto(int userid) throws CartException {

        try{
            Cart cart = getCartByUserid(userid);
            CartDto cartDto = entityToDto(cart);
            if(cart == null)
                return null;
            return cartDto;
        }catch (DataAccessException e){
            throw new CartException(Constant.EXCEPTIONINGETCART);
        }catch (Exception e){
            throw new CartException(e.getMessage());
        }
    }


    public Cart increment(int userid,int productid) throws CartException {
        try {
            Cart cart = getCartByUserid(userid);
            if(cart == null)
                throw new CartException(Constant.EXCEPTIONNOUSERFOUND);
            List<Product> products = cart.getProducts();

            for(Product product : products){
                if(product.getProductid() == productid){
                    product.setQuantity(product.getQuantity()+1);
                }
            }
            cartRepository.save(cart);
            return cart;

        } catch (CartException e) {
            throw new CartException(Constant.EXCEPTIONINDECREMENT);
        }
    }

    public Cart decrement(int userid,int productid) throws CartException{
        try{
            Cart cart = getCartByUserid(userid);
            if(cart == null)
                throw new CartException(Constant.EXCEPTIONNOUSERFOUND);
            List<Product> products = cart.getProducts();


            Iterator<Product> it = products.iterator();

            while (it.hasNext()){
                Product product = it.next();

                if(product.getProductid() == productid){

                    if(product.getQuantity() <= 1){
                        it.remove();
                        break;
                    }
                    product.setQuantity(product.getQuantity()-1);
                }
            }
            cartRepository.save(cart);
            return cart;
        }catch (CartException e){
            throw new CartException(Constant.EXCEPTIONINDECREMENT);

        }
    }

    public Cart delete(int userid,int productid) throws CartException{
        try{
            Cart cart = getCartByUserid(userid);
            if(cart == null)
                throw new CartException(Constant.EXCEPTIONNOUSERFOUND);
            List<Product> products = cart.getProducts();


            Iterator<Product> it = products.iterator();

            while (it.hasNext()){
                Product product = it.next();

                if(product.getProductid() == productid){
                        it.remove();
                        break;
                }
            }
            cartRepository.save(cart);
            return cart;
        }catch (CartException e){
            throw new CartException(Constant.EXCEPTIONINDELETE);

        }
    }


    public CartDto entityToDto(Cart cart) throws CartException {

        try {
            CartDto cartDto = new CartDto();

            cartDto.setUserid(cart.getUserid());


            List<Product> products = cart.getProducts();
            List<ProductDto> productDtos = new ArrayList<>();

            for(Product product : products){

                ProductDetails productDetails = restTemplate.getForObject(Constant.URL +product.getProductid(),ProductDetails.class);

                ProductId productId = redisRepository.findById(product.getProductid());



                if(productDetails != null){
                    ProductDto productDto = new ProductDto();
                    productDto.setProductid(product.getProductid());
                    productDto.setQuantity(product.getQuantity());

                    if(productId != null){
                        LOGGER.info("From redis");
                        productDto.setPrice(productId.getPrice());
                        productDto.setProductname(productId.getProductname());
                        productDto.setOffer(productId.getOffer());
                        productDto.setExistingquantity(productId.getExistingquantity());
                        productDto.setImageurl(productId.getImageurl());
                    }else{
                        LOGGER.info("From database");
                        productDto.setPrice(Double.parseDouble(productDetails.getPrice()));
                        productDto.setProductname(productDetails.getProductname());
                        productDto.setImageurl(productDetails.getImageurl());
                        productDto.setOffer(productDetails.getOffer());
                        productDto.setExistingquantity(productDetails.getExistingquantity());
                        redisRepository.save(new ProductId(productDto.getProductid(),productDto.getProductname(),productDto.getPrice(),productDto.getImageurl(),productDto.getOffer(),productDto.getExistingquantity()));
                    }
                    productDtos.add(productDto);
                }

            }

            cartDto.setProducts(productDtos);

            return cartDto;
        }catch (Exception e){
            throw new CartException(e.getMessage());
        }


    }


    public String deleteCartItem(int id) throws CartException{
        try {
            LOGGER.info("Deleted cart for userid: "+id);
            Cart cart = getCartByUserid(id);
            if(cart == null)
                throw new CartException(Constant.EXCEPTIONNOUSERFOUND);
            cartRepository.delete(cart);
        }catch (DataAccessException e){
            throw new CartException(Constant.EXCEPTIONINDELETE );
        }
        return "deleted";
    }




}
