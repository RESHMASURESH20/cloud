package com.example.cart.model;

public class ProductDetails {

    private String productname;
    private String price;
    private String imageurl;
    private String existingquantity;
    private int offer;

    public int getOffer() {
        return offer;
    }

    public void setOffer(int offer) {
        this.offer = offer;
    }


    public String getExistingquantity() {
        return existingquantity;
    }

    public void setExistingquantity(String existingquantity) {
        this.existingquantity = existingquantity;
    }

    public String getProductname() {
        return productname;
    }

    public void setProductname(String productname) {
        this.productname = productname;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public String getImageurl() {
        return imageurl;
    }

    public void setImageurl(String imageurl) {
        this.imageurl = imageurl;
    }


}
