package com.example.cart.model;

public class ProductDto {

    private int productid;
    private String productname;
    private double price;
    private int quantity;
    private String imageurl;
    private int offer;
    private String existingquantity;


    @Override
    public String toString() {
        return "ProductDto{" +
                "productid=" + productid +
                ", productname='" + productname + '\'' +
                ", price=" + price +
                ", quantity=" + quantity +
                ", imageurl='" + imageurl + '\'' +
                ", offer=" + offer +
                ", existingquantity='" + existingquantity + '\'' +
                '}';
    }

    public String getExistingquantity() {
        return existingquantity;
    }

    public void setExistingquantity(String existingquantity) {
        this.existingquantity = existingquantity;
    }

    public int getOffer() {
        return offer;
    }

    public void setOffer(int offer) {
        this.offer = offer;
    }

    public int getProductid() {
        return productid;
    }

    public void setProductid(int productid) {
        this.productid = productid;
    }

    public String getProductname() {
        return productname;
    }

    public void setProductname(String productname) {
        this.productname = productname;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public String getImageurl() {
        return imageurl;
    }

    public void setImageurl(String imageurl) {
        this.imageurl = imageurl;
    }

}
