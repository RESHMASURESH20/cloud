package com.example.cart.model;

import java.util.List;

public class CartDto {

    private int userid;
    private List<ProductDto> products;

    public int getUserid() {
        return userid;
    }

    public void setUserid(int userid) {
        this.userid = userid;
    }

    public List<ProductDto> getProducts() {
        return products;
    }

    public void setProducts(List<ProductDto> products) {
        this.products = products;
    }

}
