package com.example.cart.service;

import com.example.cart.exception.CartException;
import com.example.cart.model.Cart;
import com.example.cart.model.CartDto;
import com.example.cart.model.Order;
import com.example.cart.model.Product;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

public interface CartService {

    public List<Cart> addToCart(List<Cart> carts) throws CartException;
    public Cart add(Cart cart) throws CartException;
    public List<CartDto> getCart() throws CartException;
    public Cart getCartByUserid(int userid)throws CartException;
    public String deleteCartItem(int id) throws CartException;
    public Cart increment(int userid,int productid) throws CartException;
    public Cart decrement(int userid,int productid) throws CartException;
    public Cart delete(int userid,int productid) throws CartException;
    public CartDto getCartByUseridAsDto(int  userid) throws CartException;

}
