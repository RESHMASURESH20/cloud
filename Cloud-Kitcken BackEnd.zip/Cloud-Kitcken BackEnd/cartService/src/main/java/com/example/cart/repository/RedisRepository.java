package com.example.cart.repository;

import com.example.cart.model.Product;
import com.example.cart.redisEntity.ProductId;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.repository.configuration.EnableRedisRepositories;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
@EnableRedisRepositories
public class RedisRepository {

    @Autowired
    @Qualifier("redisTemplate")
    private RedisTemplate template;

    public static final String HASH_KEY = "ProductId1";

    public ProductId save(ProductId productId){
        template.opsForHash().put(HASH_KEY,productId.getId(),productId);
        return productId;
    }

    public List<ProductId> findAll(){
        return template.opsForHash().values(HASH_KEY);
    }

    public ProductId findById(int id){
        return (ProductId) template.opsForHash().get(HASH_KEY,id);
    }

    public String deleteById(int id){
        template.opsForHash().delete(HASH_KEY,id);
        return "deleted";
    }


}
