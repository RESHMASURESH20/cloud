import Vue from 'vue'
import VueRouter from 'vue-router'
import HomeComponent from '../components/HomeComponent.vue'
import OrderComponent from '../components/OrderComponent.vue';
import AdminComponent from '../components/AdminComponent.vue';
import InventoryComponent from '../components/InventoryComponent.vue';
// import ProductComponent from'../components/ProductComponent';
import RegisterComponent from '../components/RegisterComponent';
import LoginComponent from '../components/LoginComponent';
import addToCartComponent from '../components/AddToCartComponent';
import MainComponent from '../components/MainComponent.vue'
import AdminOrderHistory from '../components/AdminOrderHistory'
import UserOrderHistory from '../components/UserOrderHistory.vue'
Vue.use(VueRouter);



// function guardMyroute(to, from, next)
// {
//  var isAuthenticated= false;
// //this is just an example. You will have to find a better or 
// // centralised way to handle you localstorage data handling 
// console.log(localStorage.getItem('status'))
// if(localStorage.getItem('status')==200)
//   isAuthenticated = true;
//  else
//   isAuthenticated= false;
//  if(isAuthenticated) 
//  {
 
//   next('/user/main'); // allow to enter route
//  } 
//  else
//  {
//   next('/'); // go to '/login';
//  }
// }


const routes = [
    { path: '/', 
    component: LoginComponent ,
    beforeEnter:((to,from,next)=>{
      console.log("before")
      console.log(localStorage.getItem('status'))
      var status=localStorage.getItem('status')
      var role=localStorage.getItem('role')

      // var username=localStorage.getItem('users')
      if(status==undefined){
        next();
      }
      else if(role=='user'){
        next({path:'/user/main'});
      }
      else
      {
        next({path:'/admin/inventory'});
      }
     })
    
  },
  { path: '/home', component: HomeComponent ,
  beforeEnter:((to,from,next)=>{
    console.log("before")
    console.log(localStorage.getItem('status'))
    var status=localStorage.getItem('status')
    if(status!=undefined && status!=null && status==200){
      console.log("success")
    next()
    }
    else{
      console.log('cancel')
      next({path:'/'});
    }
   })
  },
  // { path: '/orderHistory', component:AdminOrderHistory},
  {
    path:"/orders",
    component: UserOrderHistory
   },
 {path:'/admin/',component:AdminComponent,
 beforeEnter:((to,from,next)=>{
  console.log("before")
  console.log(localStorage.getItem('status'))
  var status=localStorage.getItem('status')
  var username=localStorage.getItem('users')
  var role=localStorage.getItem('role')
  if(status!=undefined && status!=null && status==200 && username=='Cloudkitchen'){
    console.log("admin success",username)
  next()
  }
  else if(role=='user'){
    console.log('cancel')
    next({path:'/user/main'});
  }
  else
  {
    next({path:'/'});
  }
 }),

children:[
  { path: '/orderHistory', component:AdminOrderHistory,
  beforeEnter:((to,from,next)=>{
    console.log("before")
    console.log(localStorage.getItem('status'))
    var status=localStorage.getItem('status')
    var username=localStorage.getItem('users')
    if(status!=undefined && status!=null && status==200 && username=='Cloudkitchen'){
      console.log("admin success",username)
    next()
    }
    else{
      console.log('cancel')
      next({path:'/login'});
    }
   })

},
  
 {
  path:"order",
  component: OrderComponent
 },
 {
  path:"inventory",
  component:InventoryComponent,
  beforeEnter:((to,from,next)=>{
    console.log("before")
    console.log(localStorage.getItem('status'))
    var status=localStorage.getItem('status')
    var username=localStorage.getItem('users')
    if(status!=undefined && status!=null && status==200 && username=='Cloudkitchen'){
      console.log("admin success",username)
    next()
    }
    else{
      console.log('cancel')
      next({path:'/'});
    }
   })
  // children:[
  // {  path:"/orderHistory",
  //   component:AdminOrderHistoryComponent
  // }
  // ]
 },
]},
{path:'/user',component:HomeComponent,

beforeEnter:((to,from,next)=>{
  console.log("before")
  console.log(localStorage.getItem('status'))
  var status=localStorage.getItem('status')
  var username=localStorage.getItem('users')
  var role=localStorage.getItem('role')
  if(status!=undefined && status!=null && status==200 && username!="Cloudkitchen"){
    console.log("user success")
  next()
  }
  else if(role=='admin'){
    console.log('cancel')
    next({path:'/admin/inventory'});
  }
  else
  {
    next({path:'/admin/inventory'});
  }
 }),
children:[
 {
  path:"main",
  component: MainComponent,
  beforeEnter:((to,from,next)=>{
    console.log("before")
    console.log(localStorage.getItem('status'))
    var status=localStorage.getItem('status')
    var username=localStorage.getItem('users')
    if(status!=undefined && status!=null && status==200 && username!="Cloudkitchen"){
      console.log("user success")
    next()
    }
    else{
      console.log('cancel')
      next({path:'/'});
    }
   })
 // beforeEnter : guardMyroute,
 },

{
  path:"orders",
  component: UserOrderHistory
 },
//  {
//     path:":id",
//     component: ProductDescriptionComponent
  
//    },
]},
{
  path:"/register",
  component:RegisterComponent,
  beforeEnter:((to,from,next)=>{
    console.log("before")
    console.log(localStorage.getItem('status'))
    var status=localStorage.getItem('status')
    var role=localStorage.getItem('role')

    // var username=localStorage.getItem('users')
    if(status==undefined){
      next();
    }
    else if(role=='user'){
      next({path:'/user/main'});
    }
    else
    {
      next({path:'/admin/inventory'});
    }
   })

 },
 {
  path:"/login",
  name:"login",
  component:LoginComponent,
  beforeEnter:((to,from,next)=>{
    console.log("before")
    console.log(localStorage.getItem('status'))
    var status=localStorage.getItem('status')
    var role=localStorage.getItem('role')

    // var username=localStorage.getItem('users')
    if(status==undefined){
      next();
    }
    else if(role=='user'){
      next({path:'/user/main'});
    }
    else
    {
      next({path:'/admin/inventory'});
    }
   })

 },
 {
  path:"/cart",
  component:addToCartComponent
 }
  // { path: '/admin', component:AdminComponent },
  // { path: '/admin/order', component: OrderComponent}
 
 ]
 const routerlist = new VueRouter({
  routes:routes,
  mode:"history",
  base:process.env.BASE_URL
 })
//  routerlist.beforeEach((to,from,next)=>{
//   console.log(localStorage.getItem('status'))
// if(to.meta.requireAuth){
//   if(localStorage.getItem('status')==200){
//     console.log("success")
// next({
  
//   path:"/user/main",
  
// })
//   }
//   else{
//     next();
//   }

// }
// else{
//   next();
// }
//  })
 export default routerlist;



