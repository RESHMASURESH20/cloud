import HeaderComponent from '../components/HeaderComponent';
export default {
  
    components: { 
        HeaderComponent
    }
};