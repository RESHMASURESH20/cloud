import { loginUser } from "@/service/login.service"
import { mapGetters } from "vuex"
export default{
    data(){
       return{
        rules: [
          value => !!value || 'Required.',
          // value => (value && value.length >= 5) || 'Min 5 characters',
        ],
        error:"",
         user:{
            uname:"",
            upassword:"",
            userType:""
         },
         disable:false,
         invalidError:"",
         Loggedin:""
       }
    },
    computed:
    {
      ...mapGetters({
       
        successFlag:'getFlag'
      })
    },
    methods:{
      role(){
        if(this.user.userType=='customer'){
          this.disable=true
        }
        else{
          this.disable=false
        }
      // role(){
      //   this.disable=true
      // }
      },
        userLogin(){
           
            var payload={
                userName : this.user.uname,
                loginPassword : this.user.upassword,
                userType : this.user.userType
            }
            
             if(payload.uname!='' && payload.loginPassword!= '' && payload.userType!=''){
              console.log(payload)
            loginUser({
                
                success : (response) => {
               
                  localStorage.setItem("users",this.user.uname)
                  localStorage.setItem("status",response.status)
                  console.log(response)
                  console.log("status", localStorage.getItem("status"))
                  if(response.data==true){
                 
                   // this.Loggedin="please LogOut you have Already Logged in "
                    if(this.user.userType=="admin")
                    {
                      console.log("login success")
                      this.$router.push({path:"/admin/inventory"})
                      localStorage.setItem('role','admin');
                      
                    }
                    else{
                      this.$router.push({path:"/user/main"})
                      localStorage.setItem('role','user');
                      
        
                    }
                     
                  }
                  else{
                    this.invalidError="Invalid Credentials"
                  }
                },
                error : (e) => {
                  console.log(e)
                   alert("error")    
                },
                object:payload
            })}
            else{
              console.log(this.error)
              this.error="Please enter all the fields"
            }
        },
        userReset(){
            this.user.uname="";
            this.user.upassword="";
            this.user.userType = "";
        },
       
        
    }

    
}