import EditProductComponent from "../components/EditProductComponent.vue"
import {UserHistory,deleteProduct} from "../service/product.service"
import {cancelOrder,confirmcancelOrder} from "../service/cart.service"
import { mapGetters } from 'vuex';
//  import AdminOrderHistoryComponent from '../components/AdminOrderHistory.vue'
export default {
    data () {
      return {
        orderId:'',
        date:new Date().toLocaleDateString()+" "+new Date().toLocaleTimeString(),
        product:{
            foodName:"",
            category:"",
            itemType:"",
            price:"",
            cuisine:"",
            rating:"",
            duration:"",
            offer:"",
            coupon:"",
            stockCount:null,
            description:"",
            image:"",

        },
        loader:false,
        id:"",
        item:"",
        dialog:false,
        dialog1:false,
        search: '',
        name:"InventoryComponent",
       
        dialog2:false,
        components:{
          EditProductComponent,
          // AdminOrderHistoryComponent
          
        },
         rules: [
                value => !!value || 'Required.',
                value => (value && value.length >= 3) || 'Min 3 characters',
              ],
        headers: [
          { text: 'orderId', value: 'orderId' },
          { text: 'Food Name', value: 'product' },
         // { text: 'Name', value: 'name' },
        //   { text: 'Item type', value: 'itemType' },
        //   { text: 'Category', value: 'category' },
        //   { text: 'cuisine', value: 'cuisine' },
         
          { text: 'Price', value: 'price' },
          {text:'Quantity',value:'quantity'},
          { text: 'TotalPrice', value: 'totalprice' },
       //   {text:'Amount',value:'amount'},
        //  {text:'Status',value:'status'},
        //   { text: 'description', value: 'description' },
        //   { text: 'rating', value: 'rating' },
        //   { text: 'duration', value: 'duration' },
        //  { text: 'Offer', value: 'offer' },
        //   { text: 'coupon', value: 'coupon' },
        
        //   { text: 'Availablity', value: 'stockCount' },
          { text: 'Status', value: 'Status' },
       //   { text: 'Status', value: 'Status' },
        ],
     products:[],
      }
    },

   mounted()
    {
      this.UserHistoryList()
      console.log("userid",localStorage.getItem("userid"))
     
    },
    methods:{
       
      order(){
        alert('hello')
        this.$router.push({path:'/orderHistory'})
      },
      cancel(orderid,item){
        this.loader=true,
       setTimeout(()=>(this.cancelor(orderid,item)),1000)
      

      },
     cancelor(orderid,item)
     {
        console.log("cancel function",this.date,orderid)
          cancelOrder({
                  date:new Date().toLocaleDateString()+" "+new Date().toLocaleTimeString(),
                  orderid,
                  success : (data) => {
                    this.loader=false,
                     console.log("hiii",data.data)
                       if(data.data==true)
                       {
                       this.dialog=true
                       this.id=orderid
                       this.item=item
                       }
                       else  
                     
                     this.$alert(' Cancel Unavailable')
  
                  },
  
                  error : (e) => {
  
                     alert(e)
  
                  },
  
              })
  
          },
          yes(){
            confirmcancelOrder({
              orderid:this.id,
              success : (data) => {
               // this.item.status="cancelled"
                console.log(data)
                this.dialog=false;
              //  this.dialog1=true;
                this.$alert(' Cancelled Successfully')
                this.UserHistoryList()
                
              },

              error : (e) => {

                 alert('yes error',e)

              },

          })
        },
       
      UserHistoryList()
      {
        UserHistory ({
          success : (response) => {
            console.log("inside method",response.data)
           // console.log("hii",response.data[0].orderId)
            this.products=response.data
            this.orderId=response.data.orderId

  
          },
          error : (e) => {
            console.log(e)
            
          },value:localStorage.getItem("userid")
      })
      },
      deleteItem(item)
      {
        deleteProduct({
          success : (response) => {
            
            console.log(response)
              this.getProductsList()
          },
          error : (e) => {
            console.log(e)
             alert("error")
          },
          object:item.foodId
      })
      },
      
    },
    components: { 
        
    },
    computed:
  {
    ...mapGetters({
    
      successFlag:'getFlag'
    })
  },
  }
