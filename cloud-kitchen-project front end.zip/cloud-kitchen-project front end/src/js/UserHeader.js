export default {
    name:"UserHeaderComponent",
    data: () => ({
      drawer: false,
      group: null,
      uname:localStorage.getItem("username")
    }),
    methods:{
      movePage()
      {
        console.log("movepage")
     //   this.$router.push(value)
        this.$router.push("orders")
      },
      logout()
      {
        sessionStorage.removeItem("status");
        localStorage.setItem("users",[])
        localStorage.removeItem("status");
        localStorage.removeItem("role");
        this.$router.push({name:"login"})
        localStorage.removeItem("username");
      
      }
    }
}