import EditProductComponent from "../components/EditProductComponent.vue"
import {createProduct,getProduct,deleteProduct,editProduct} from "../service/product.service"
//  import AdminOrderHistoryComponent from '../components/AdminOrderHistory.vue'
export default {
    data () {
      return {
        succes:false,
        del:false,
        product:{
            foodname:"",
            category:"",
            price:null,
            cuisine:"",
            offer:"",
            stockCount:0,
            description:"",
            url:"",
           // foodId:null
        },
        timerCount: 30,
        error:'',
        foodId:'',
        search: '',
        name:"InventoryComponent",
        dialog:false,
        dialog2:false,
        dialog3:false,
        components:{
          EditProductComponent,
          // AdminOrderHistoryComponent
          
        },
         rules: [
                value => !!value || 'Required.',
                value => (value && value.length >= 3) || 'Min 3 characters',
                value=>(typeof(value)==="string")||'it should be a name'
              ],
              pricerules:[
                value => !!value || 'Price Required.',
                value=>(value && value!=0)||'Price should not be zero',
                value=>(value && value>=0)||'Price should not be negative',
                value=>(value && value<=1000)||'Price should not be greater than 1000'
              ],
              offerrules:[
                value => !!value || 'Offer Required.',
                value=>(value && value!=0)||'Offer should not be zero',
                value=>(value && value>=0)||'Offer should not be negative',
                value=>(value && value<=100)||'Offer should not be greater than 100'
              ],
              stockrules:[
                value => !!value || 'Stock Required.',
                value=>(value && value!=0)||'Stock should not be zero',
                value=>(value && value>=0)||'Stock should not be negative',
                value=>(value && value<=100)||'Stock should not be greater than 100'
              ],

        headers: [
          { text: 'url', value: 'url' },
          { text: 'Product Name', value: 'foodname' },
          // { text: 'Item type', value: 'itemType' },
          { text: 'Category', value: 'category' },
          { text: 'cuisine', value: 'cuisine' },
          { text: 'price', value: 'price' },
          { text: 'description', value: 'description' },
          // { text: 'rating', value: 'rating' },
          // { text: 'duration', value: 'duration' },
          { text: 'offer', value: 'offer' },
          // { text: 'coupon', value: 'coupon' },
        
          { text: 'Availablity', value: 'stockCount' },
          { text: 'Actions', value: 'Actions' },
        ],
     products:[],
      }
    },
   mounted()
    {
      this.getProductsList()
     
    },
   
    methods:{
      countDownTimer() {
        if(this.countDown > 0) {
            setTimeout(() => {
                this.countDown -= 1
                this.countDownTimer()
            }, 1000)
        }
    },
      order(){
      
        this.$router.push({path:'/orderHistory'})
      },
      getProductsList()
      {
        getProduct({
          success : (response) => {
            console.log('get product',response)
            this.products=response.data
           // this.product.foodId=response.data[0].foodId
  
          },
          error : (e) => {
            console.log(e)
            
          },
      })
      },
      deleteItem(item)
      {
        deleteProduct({
          success : (response) => {
            
            console.log(response)
              this.getProductsList()
              this.del=true
              
          },
          error : (e) => {
            console.log(e)
             alert("error")
          },
          object:item.foodId
      })
     
      },
      editItem(item)
      {
        console.log('inside edit',item)
        this.product=item;
       // console.log(this.product)
      //   editProduct({
      //     success : (response) => {
            
      //       console.log(response)
      //        this.getProductsList()
      //     },
      //     error : (e) => {
      //       console.log(e)
      //        alert("error")
      //     },
      //     object:item.product
      //    // object:item.foodId
      // })
      
      },
      editsave(){
        editProduct({
          success : (response) => {
            
            console.log(response)
             this.getProductsList()
             this.dialog3=false
          },
          error : (e) => {
            console.log(e)
             alert("error")
          },
          object:this.product
         // object:item.foodId
      })
      },

      saveInventory()
      { 
        if(this.product.foodname!=''&& this.product.category!='' &&  this.product.price!=''&& this.product.cuisine!=''&& this.product.offer!='' && this.product.stockCount!=''&& this.product.description!=''&& this.product.image!=''){
         console.log(this.product)
         createProduct({
          success : (response) => {
            
            console.log(response)
            this.product=""
             this.dialog=false
             
              // window.location.reload();
            
              this.getProductsList()
              

          },
          error : (e) => {
            console.log(e)
             alert("error")
          },
          object:this.product
      })
      }else{
        this.error="Please enter all the fields"
      }
      this.$alert("Product Added successfully");
      this.product=""
      
    }
      
    },
   
    components: { 
        
    }
  }
