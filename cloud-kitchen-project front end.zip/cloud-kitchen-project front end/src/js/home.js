import  UserHeaderComponent from "../components/UserHeaderComponent.vue"
import CartComponent from "../components/CartComponent.vue"
import FooterComponent from '../components/FooterComponent'
import ProductsdisplayComponent from "../components/ProductsdisplayComponent.vue"
export default {
    name:"HomeComponent",
    components:{
        UserHeaderComponent,
        CartComponent ,
        ProductsdisplayComponent,
        FooterComponent
    }
}