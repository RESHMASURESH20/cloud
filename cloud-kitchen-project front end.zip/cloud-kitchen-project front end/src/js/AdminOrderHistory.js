import EditProductComponent from "../components/EditProductComponent.vue"
import {deleteProduct, getHistory,deliverOrder} from "../service/product.service"
//  import AdminOrderHistoryComponent from '../components/AdminOrderHistory.vue'
export default {
    data () {
      return {
        product:{
            foodName:"",
            category:"",
            itemType:"",
            price:"",
            cuisine:"",
            rating:"",
            duration:"",
            offer:"",
            coupon:"",
            stockCount:null,
            description:"",
            image:""
        },
        search: '',
        name:"InventoryComponent",
        dialog:false,
        dialog2:false,
        components:{
          EditProductComponent,
          // AdminOrderHistoryComponent
          
        },
         rules: [
                value => !!value || 'Required.',
                value => (value && value.length >= 3) || 'Min 3 characters',
              ],
        headers: [
          { text: 'OrderId', value: 'orderId' },
          { text: 'Product Name', value: 'product' },
        //   { text: 'Item type', value: 'itemType' },
        //   { text: 'Category', value: 'category' },
        //   { text: 'cuisine', value: 'cuisine' },
          { text: 'Price', value: 'price' },
          { text: 'TotalPrice', value: 'totalprice' },
        
          {text:'Quantity',value:'quantity'},
          { text: 'Delivery Status', value: 'Status' },
        //   { text: 'description', value: 'description' },
        //   { text: 'rating', value: 'rating' },
        //   { text: 'duration', value: 'duration' },
      //    { text: 'Offer', value: 'offer' },
        //   { text: 'coupon', value: 'coupon' },
        
        //   { text: 'Availablity', value: 'stockCount' },
        //  { text: 'Actions', value: 'Actions' },
        ],
     products:[],
      }
    },
    mounted()
    {
      this.getHistoryList()
     
    },
    methods:{
      order(){
        alert('hello')
        this.$router.push({path:'/orderHistory'})
      },
      getHistoryList()
      {
        getHistory({
          success : (response) => {
            console.log('inside methods',response.data)
            this.products=response.data
            console.log(this.products)
          },
          error : (e) => {
            console.log(e)
            
          },
      })
      },
      deliver(orderid,item)
     {
        console.log("cancel function",orderid)
          deliverOrder({
            
                 object: orderid,
                  success : (data) => {
                    this.loader=false,
                     console.log("hiii",data.data)
                       if(data.data==true)
                       {
                       this.dialog=true
                       this.id=orderid
                       this.item=item
                       }
                       else  
                     
                     this.$alert('Delivered')
                     this.getHistoryList()
  
                  },
  
                  error : (e) => {
  
                     alert(e)
  
                  },
  
              })
  
          },
      deleteItem(item)
      {
        deleteProduct({
          success : (response) => {
            
            console.log(response)
              this.getProductsList()
          },
          error : (e) => {
            console.log(e)
             alert("error")
          },
          object:item.foodId
      })
      },
      
    },
    components: { 
        
    }
  }
