import ProductItemCartComponent from '../components/ProductItemCartComponent.vue'
export default {
    name:'ProductDescriptionComponent',
    components:{
        ProductItemCartComponent
    }
}