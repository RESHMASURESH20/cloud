  import {registerUser} from "../service/register.service"
  export default {
    data: () => ({
        
        rules: [
          value => !!value || 'Required.',
          value => (value && value.length >= 5) || 'Min 5 characters',
        ],
        rulesno: [
          value => !!value || 'Required.',
          value => (value && value.length == 10) || 'Invalid number',
        ],
        emailrules: [
          (v) => !!v || "Email is required",
          (v) => /.+@.+\..+/.test(v) || "Email must be valid",
       ],
       success:false,
        error:false,
        error1:"",
        passerror:false,
        user:{
          username:"",
          name:"",
          mobno:"",
          address:"",
          email:"",
          password:"",
          cpassword:""
        },
        message:"",
        passwordError:"password mismatch",
        errorFlag:false
      }),

      // watch:{
      //   "user.password"(){
      //     console.log(this.user.password)
      //   if(this.user.password==this.user.cpassword){
      //     this.errorflag=true
      //     console.log('error')
      //   }
    

      //   }
      // },
      computed:{
        allFields(){
        if(this.user.username!=''&& this.user.mobno!=''&& this.user.address!=''&& this.user.email!=''&&this.user.password!=' '){
               this.error=false
        }
        return this.error
      },
      pass(){
        if(this.user.password!=this.user.cpassword){
          this.passerror=true
        }
        else{
          this.passerror=false
        }
        return this.passerror
      }
      },
      methods:{
        check(){
          this.message="pass"
        },
        register()
        {
          console.log("register")
          if(this.user.username==''||this.user.mobno==''||this.user.address==''||this.user.email==''||this.user.password==' '|| this.user.name=='')
          {
            
            this.error=true
            console.log("empty")
            
          }
           else if(this.user.password!=this.user.cpassword)
          {
            console.log("not empty")
            this.error="Password does not match"
          }
          else
          {
            console.log("empty")
            this.error=" "
            console.log("resgister succes")
          localStorage.setItem("users",[])
          var payload={
            "userName":this.user.username,
            "phoneNo":this.user.mobno,
            "address":this.user.address,
            "email":this.user.email,
            "userType":"Customer",
            "loginPassword":this.user.password,
            "name":this.user.name
           }
          console.log(payload)
          registerUser({
            success : (response) => {
              localStorage.setItem("admin", JSON.stringify(response.data));
             
              
              console.log(response.data)
                alert('Registration successful')
                this.success=true,
                 this.username="";
               this.$router.push({path : `/login`})
            
            },
            error : (e) => {
              console.log(e)
              if(e.message.includes("409")){
                alert('user name exists')
              }
              else{
                alert(e)
              }
             //  alert(e.message.includes("409"))
            },
            object:payload
        })
        this.error=""
      }
        },
        goLogin(){
            this.$router.push({path : `/login`})
        }
      }
    
  }
