import { mapGetters } from 'vuex';
import {placeorder} from '../service/cart.service'
// import {deletecart} from '../service/checkout'

       export default{
        data(){
            return{
              num:"",
        flag:false,  
        dialog2:false,
        dialog1:false,
        userid:'123456',
        
    //   userid:this.$router.query.id
       
        }},
        computed:{
            ...mapGetters({
             cartlist:'getCartlist',
             final:'getTotalPrice',
            //  netPrice:'getNetPrice'
            //  orderlist:'getorder'
        }),
      },
        methods:{
          check(){
            this.dialog2=true
          },
          place(){
             this.num=""
              var order={
                userId:this.userid,
                name:"kalai",
                phonenumber:"9732482322",
                alternativenumber:this.num,
                totalprice:this.final.totalprice,
                netprice:this.final.netprice,
                 cart:this.cartlist
              }
              console.log("Post"+order);
            placeorder ({
              order,

                success : ({data}) => {
                    console.log(data)
                    this.dialog2=false;
                    this.dialog1=true;
                    // this.$store.dispatch('GET_ORDER',order)
                },
                error : (e) => {
                   console.log(e)
                },
               
            })
           

          //  deletecart({
          //   success : ({data}) => {
          //           console.log(data)
          //       },
          //       error : (e) => {
          //          console.log(e)
          //       },
          //       // id:userid
          //  })
          },
          close(){
            //console.log(localStorage.getItem(this.user.username))
            this.dialog2=false;
            this.name="";
             this.number="";
          }
        },
        created(){
          this.$store.dispatch("getcartitemsfromservice",this.userid)
        },
        // mounted() { 
        //   this.total=0;
        //   console.log("mpunted")
        //   console.log(this.cartlist)
        //   this.cartlist.forEach((element) => {
        //         this.total += element.price * element.quantity;
        //     });
        //     this.finaltotal = this.total + (this.total * this.discount) / 100;

        //   }
        
    }