
<template>
<div class="loginchange" id="bg">
<div>
 <v-img
 class="img"
 lazy-src="../assets/logo1.png"
 max-height="150"
 max-width="250"
 src="../assets/logo1.png"
></v-img>
 </div>
 <v-card
  class="mx-auto">
 <v-container class="card">
  <v-card-title>
  Login  <span class="errortext1">{{this. invalidError}}</span>
   <span class="errortext1">{{this.Loggedin}}</span>
 </v-card-title>
  <v-row cols="12">
  <v-col>
  <v-text-field v-model="user.uname" filled rounded solo dense
   label="Username"
   :rules="rules"
   hide-details="auto"
  >
  </v-text-field>
  </v-col>
  </v-row>
  <v-row cols="12">
  <v-col>
  <v-text-field v-model="user.upassword" filled rounded solo dense
   label="Password"
   :rules="rules"
   type="password"
   hide-details="auto"
  >
  </v-text-field>
  </v-col>
  </v-row>
  <v-row cols="12">
  <v-col >
  <v-select
  :items="['admin', 'customer']"
   v-model="user.userType" filled rounded solo dense
  label="UserType"
 ></v-select>
  </v-col>
  </v-row>
  <span class="errortext">{{this.error}}</span>
   <div class="account" v-if="user.userType=='customer'" ><router-link to="/register">Don't have account ?</router-link></div>
  <br>
<div class="">
  <v-row cols="12">
 
    <v-col lg="6" md="12" sm="12">
    <v-btn @click="userReset()"
    color="#fc9403"
 block
 elevation="2"
 raised
 rounded
 style="color:white"
>Reset</v-btn>
</v-col>
<v-col lg="6" md="12" sm="12">
    <v-btn @click="userLogin()"
    :disabled="successFlag"
    color="#fc9403"
 block
 elevation="2"
 raised
 rounded
 style="color:white"
>Login</v-btn>
</v-col>
  </v-row>
  
</div>
  
  </v-container>
 </v-card>
</div>
</template>

<style scoped>
.mx-auto{
 max-width:500px
}
#bg{
 background-image: url("../assets/rice.webp");
   background-size: 100% 100%;
}

.mx-auto{
 margin-left: 16%!important;
}
 .loginBtn{
  width: 20vw;
  margin-left: 80px;
 }
 .card{
  height: max-content;
  margin-top: 10%;
 }
 .loginchange{
  /* background-color: rgb(149, 144, 144); */
  height: 100%;
  /* width: 100%; */
  /* background-image: url("https://img.wallpapersafari.com/desktop/1024/576/91/87/NLIx25.jpg"); */
  /* background-size: auto; */
 
 }
 .mx-auto{
  border-radius: 20px;
 }
 .account{
  text-align: center;
 }
 .errortext{color: red;
text-align: center;}
.errortext1{color: red;
text-align: center;
margin-left: 100px;}

@media screen and (max-width : 350px) {
 .mx-auto{
  margin-left:2%!important;
  margin-right:2%!important;
  width:fit-content;
 
 }
 .img{
  width:90px;
  height:60px;
 }
}
</style>

<script src="../js/loginComponent.js"></script>

