<template>
    <div >
        <div>
         <ProductsdisplayComponent/>
      </div>
      <div>
         <CartComponent/>
      </div>
    </div>
</template>
<script>

import CartComponent from "../components/CartComponent.vue"
import ProductsdisplayComponent from "../components/ProductsdisplayComponent.vue"
export default {
    name:"MainComponent",
    components:{
   
        CartComponent ,
        ProductsdisplayComponent
    }
}
</script>
<style scoped>
.body-element
{
   display:flex;
   flex-direction:row;
   justify-content: space-between;
}
</style>