[4:52 pm] Kalaivathi M
<template>
<div class="change" id="bg">
 <v-card
  class="mx-auto"
  max-width="500"
 >
 <v-alert
 dismissible
 elevation="24"
 v-if="success"
 type="success"
>success</v-alert>
 <v-container class="register-card">
  <v-card-title>
  Register
 </v-card-title>
 <v-container>
  <v-row cols="12">
  <v-col lg="6" md="12" sm="12">
  <v-text-field filled rounded solo dense
   label="Username"
   v-model="user.username"
   :rules="rules"
   hide-details="auto"
  >
  </v-text-field>
    </v-col>
    <v-col lg="6" md="12" sm="12">
  <v-text-field filled rounded solo dense
   label="Name"
   v-model="user.name"
   :rules="rules"
   hide-details="auto"
  >
 
  </v-text-field>
    </v-col>
  <v-col lg="12" md="12" sm="12">
  <v-text-field rounded filled solo dense
   label="Contact no"
   :rules="rulesno"
   v-model="user.mobno"
   hide-details="auto"
  >
  </v-text-field>
    </v-col>
  </v-row>

  <v-row cols="12">
  <v-col lg="6" md="12" sm="12">
  <v-text-field rounded filled solo dense
   label="Password"
   v-model="user.password"
   type="password"
   :rules="rules"
   hide-details="auto"
  >
  </v-text-field>

    </v-col>
  <v-col lg="6" md="12" sm="12">
  <v-text-field rounded solo dense filled
   label="Confirm Password"
   :rules="rules"
   type="password"
    v-model="user.cpassword"
   hide-details="auto" >
 
  </v-text-field>
<span v-if="pass" class="errortext">password mismatch</span>
    </v-col>
  </v-row>
   <span lg="6" md="12" sm="12" v-if="user.password!=user.cpassword" class="errortext" style="font-size:1.2vw">{{this.error1}}</span>
  <v-row>
    <v-col lg="12">
      <v-text-field rounded solo dense filled
   label="Email id"
   :rules="emailrules"
   type="email"
   v-model="user.email"
   hide-details="auto"
  >
  </v-text-field>
    </v-col>

  </v-row>
  <v-row>
   <v-col lg="12" md="12" >
    <v-textarea rounded solo dense filled
     name="input-7-4"
     label="Address"
     v-model="user.address"
    ></v-textarea>
    </v-col>
  </v-row>
   <span v-if="allFields" class="errortext">enter all the fields</span>
 </v-container>

<div class="reg-button">
  <v-row cols="12">
    <v-col lg="6" md="12" sm="12">
    <v-btn @click="register()"
    color="#fc9403"
    style="color:white"
 block
 elevation="2"
 raised
 rounded
>Register</v-btn>
</v-col>
<v-col lg="6" md="12" sm="12">
    <v-btn @click="goLogin()"
    color="#fc9403"
 block
 elevation="2"
 raised
 style="color:white"
 rounded
>Login</v-btn>
</v-col>
  </v-row>
  
</div>
  
 
  </v-container>
 </v-card>
</div>
</template>

<style scoped>
#bg{
 background-image: url("../assets/register.jpeg");
   background-size: 100% 100%;
}
.register-card{
margin-top:10%;

}
.errortext{color: red;
text-align: center;}
.mx-auto{
  margin-left: 300px;
  border-radius: 30px;
}
.buttons{
  margin-left:5rem;
}
.change{
  background-color:whitesmoke;
  height: 100vh;

}
.reg-button{
  margin-left: 30px;
  margin-right: 30px;
}
</style>

<script src="../js/registerComponent.js"></script>

