<template>
<div> 
<v-container class="order" >
  <div class="text-center">
    
    <v-dialog
      v-model="loader"
      v-if="loader"
      hide-overlay
      persistent
      width="300"
    >
      <v-card
        color="#fc9403"
        dark
      >
        <v-card-text>
         Your Request is being processing
          <v-progress-linear
            indeterminate
            color="white"
            class="mb-0"
          ></v-progress-linear>
        </v-card-text>
      </v-card>
    </v-dialog>
  </div>
    <v-card-title class="inventory-top">
      <v-card-text style="padding:3px;float:right!important;color:red"><sup>*</sup>Order should be cancelled within 10 mins </v-card-text>
      Order History
      <v-spacer></v-spacer>
      <v-text-field
        v-model="search"
        append-icon="mdi-magnify"
        label="Search"
        single-line
        hide-details
      ></v-text-field>
    </v-card-title>
    <v-data-table
      :headers="headers"
      :items="products"
      :search="search"
    >
 <template v-slot:[`item.product`]="{ item }">
      <p v-for="dish in item.product" :key="dish.productid">{{dish.productname}}</p>
</template>
<template v-slot:[`item.price`]="{ item }">
      <p v-for="dish in item.product" :key="dish.productid">{{dish.price}}</p>
</template>
<template v-slot:[`item.quantity`]="{ item }">
      <p v-for="dish in item.product" :key="dish.productid">{{dish.quantity}}</p>
</template>
<template v-slot:[`item.url`]="{ item }">
  <img width="100" height="100" :src="item.url" alt="hjh" srcset="">
</template> 

 <template v-slot:[`item.Status`]="{ item }">
       {{item.status}}
   
      <!-- <v-icon
        small
        @click="deleteItem(item)"
      >
        mdi-delete
      </v-icon> -->
      <v-btn
  color="#fc9403"
  elevation="24"
  @click="cancel(item.orderId,item,item.date) "
  v-if="item.status=='Ordered'" :disabled="successFlag" style="color:white;width:fit-content;font-size:10px;font-weight:bold;padding:4px;"
>Cancel</v-btn>
    </template>
    </v-data-table>
  
</v-container>

<v-alert

      border="top"

      color="red lighten-2"

      dark

      v-if="dialog1"
     
    >

      Cancelled successfully

    </v-alert>

    <v-alert

      border="top"

      color="red lighten-2"

      dark

      v-if="dialog2"

    >

      Cancel unavailable

    </v-alert>
  <v-dialog

        v-model="dialog"

        persistent

        max-width="400px"

      >

      

      <v-card>

        <v-card-title class="text-h8">

          Are you sure?

        </v-card-title>

         <v-card-actions>

          <v-spacer></v-spacer>

          <v-btn

            color="green darken-1"

            text

            @click="yes()"

          >

             Yes

          </v-btn>

          <v-btn

            color="red darken-1"

            text

            @click="dialog = false"

          >

              No

          </v-btn>

        </v-card-actions>

      </v-card>

      </v-dialog>
</div>
</template>

<style scoped>
    
     .inventory-top{

      margin-top:1%!important;

    }
   .swal2-styled {
      background-color:#fc9403!important;
       font-weight:bold;
    }
     .order{
    margin-top: 60px;
    box-shadow: 1px 3px 9px 10px rgba(209, 201, 209, 0.82); 
    /* border-radius: 50px;  */
    height: max-content;
    }
     
     
    /* .v-btn{
       font-size: 0.7vw!important;
    width: 5% !important;
    } */
    /* button{
      font-size: 0.7vw!important;
    width: 5% !important;
    } */
</style>
<script src="../js/UserOrderHistory.js"/>