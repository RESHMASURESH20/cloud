<template>
  <div class="search-element">

       <div class="search-text">

         <input type="text" placeholder="enter food item" v-model="searchtext">

       </div>

       <div class="search-button">
         <ion-icon name="search-outline" size="large" @click="search()"></ion-icon>
       </div>  

        <div>
          <input class="clear-searchs" type="button" value="Clear search" @click="clear()">
       </div>  

    </div>
</template>

<script>

export default {
   
   methods:
    {
        search()
        {   
            //alert(this.searchtext);
            this.$store.dispatch('searchfooditemsfromservice',this.searchtext);
        },
        clear()
        {
          //  this.searchtext=""
           console.log("clear",this.searchtext)
           this.$store.dispatch('getfooditemsfromservice');

        },
    }
}
</script>

<style scoped>

input[type="text"]

{

  

  
  
  width:350px;
  padding:7px;
   border-radius:7px;
  background-color: #f9f9f9;
  
  
  height:30px;

}

.clear-searchs
{
  
  color:grey;
  border-style:solid;
  width:100px;
  border-color:grey;

  font-family: arial;
   font-size:12px;
   /* width:200px; */
   margin-left:10px;
   margin-top:5px;
}


/* input[type="button"]

{

  border-radius:3px;

  border-color:orange;

  color:rgb(242, 190, 95);

  background-color:white;

  padding:3px;

 

  font-size:13px;

  height:30px;

} */



.search-element
{    

    display: flex;

    flex-wrap:wrap;

    flex-direction:row;

    justify-content:center;
    /* width:700px; */
    margin-top:20px;

    margin-left:55px;

}

@media only screen and (max-width : 770px){

/* .search-element
{
  flex-direction: column; 
   margin-left:600px;
  
  justify-content: center;
} */

.search-button
{
    margin-left:10px;
}

input[type="text"]

{

  /* margin-left:0px; */
  width:150px;
  border-radius:7px;
  background-color: #f9f9f9;

}

}
</style>



