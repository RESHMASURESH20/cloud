<template>
  <v-footer class="footer" dark padless>
    <v-card flat tile class="black lighten-1 white--text text-center" style="width:100%;background-color:#fc9403!important">
      <!-- <v-card-text>
        <v-card class="mx-auto" max-width="344" style="background-color:white">   
          <v-card-title style="color:black"> 
           *** For the love of delcious food ***
         </v-card-title>
        </v-card>
      </v-card-text> -->
      <v-divider></v-divider>
   
      <v-card-text class="white--text" >
        
        {{ new Date().getFullYear() }} — <strong>Cloud Kitchens</strong>
        <div class="media">
            <a href="https://twitter.com/i/flow/login" target="_blank"><ion-icon name="logo-twitter"></ion-icon></a>
        <a href="https://in.linkedin.com/" target="_blank"><ion-icon name="logo-linkedin"></ion-icon></a>
<a href="https://www.instagram.com/accounts/login/" target="_blank"><ion-icon name="logo-instagram"></ion-icon></a>
        <a href="https://www.facebook.com/campaign/landing.php?campaign_id=14884913640&extra_1=s%7Cc%7C550525804944%7Cb%7Cfacebook%20%27%7C&placement=&creative=550525804944&keyword=facebook%20%27&partner_id=googlesem&extra_2=campaignid%3D14884913640%26adgroupid%3D128696220912%26matchtype%3Db%26network%3Dg%26source%3Dnotmobile%26search_or_content%3Ds%26device%3Dc%26devicemodel%3D%26adposition%3D%26target%3D%26targetid%3Dkwd-327195741349%26loc_physical_ms%3D1007810%26loc_interest_ms%3D%26feeditemid%3D%26param1%3D%26param2%3D&gclid=EAIaIQobChMItfbry9nP-QIVmpJmAh2LWwZZEAAYASAAEgKCifD_BwE" target="_blank"><ion-icon name="logo-facebook"></ion-icon></a>
      </div>
      </v-card-text>
    </v-card>
  </v-footer>
</template>

  <script>
export default {
  data: () => ({
    show: false,

   }),
};
</script>

  <style scoped>
    a{
      font-size:20px;
      padding:4px;
    }
    ion-icon{
      color:white
    }
    .media{
      float:right;
      
    }
    .footer
    {
      margin-top:600px;
    }
    @media only screen and (max-width : 300px)
    {
      .media{
        float:none;
      }
    }
</style>
