<template>
<div> 
    <HeaderComponent/>
       
  </div>
 </template>
  

<script src="../js/adminComponent.js"/>
   
