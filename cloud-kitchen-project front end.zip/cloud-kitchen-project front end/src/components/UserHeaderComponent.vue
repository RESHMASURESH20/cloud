<template>
  <div class="header">
    <v-app-bar
      color="black"
      dense
      dark
    >
      <!-- <v-app-bar-nav-icon></v-app-bar-nav-icon> -->
<ion-icon name="cloudy-outline" style="font-size:20px"></ion-icon>
      <v-toolbar-title>&nbsp;Cloud&nbsp;Kitchen</v-toolbar-title>
      <v-spacer></v-spacer> 
     <ul>  <li><router-link to="/user/main">Home</router-link></li>
            <li><router-link to="/user/orders">My orders</router-link></li>
     </ul>
     <!-- <div class="d-flex-buton">
      
        <v-btn  @click="movePage('/user/')" class="white btn-class product" style="color:black">My Orders</v-btn> 
      
    <v-btn   @click="movePage('/cart')" class="white btn-class cart" style="color:black">Cart</v-btn>
     <v-btn   @click="logout()" class="deep-purple accent-4  btn-class">Logout</v-btn>
     
     
     
      
     </div> -->

      <!-- <v-btn icon>
        <v-icon>mdi-heart</v-icon>
      </v-btn> -->

      <!-- <v-btn icon>
        <v-icon>mdi-magnify</v-icon>
      </v-btn> -->

      <v-menu
        left
        bottom
      >
        <template v-slot:activator="{ on, attrs }">
          <v-btn
            icon
            v-bind="attrs"
            v-on="on"
          
          >
            <!-- <v-icon>mdi-dots-vertical</v-icon> -->
            <ion-icon name="person-outline" style="font-size:20px"></ion-icon>
          </v-btn>
        </template>

        <v-list style="padding:2px!important;margin-top: 50%;">
          <v-list-item>
            <v-list-item-title>
              {{uname}}
            </v-list-item-title>
          </v-list-item><hr>
          <v-list-item
          
          >
            <!-- <v-list-item-title @click="logout()">logout</v-list-item-title> -->
            <v-list-item-title @click="logout()">logout</v-list-item-title>
          </v-list-item>
        </v-list>
      </v-menu>
    </v-app-bar>
  </div>
</template>
<script src="../js/UserHeader.js">
</script>
<style scoped>
.header{
  position: sticky;
    z-index: 1;
    top: 0;
}
.cart{
      margin-right: 152px;
}
.links{
margin-left:20px;
text-decoration: none;
color: white;
}
.d-flex-buton{
 
  margin-left: 8%;
}
.product{
  margin-right: 10px;
}
ul{
  list-style: none;
  display: flex;
}
li a{
text-decoration: none;
color: #fff;
}
li{
      padding-left: 10px;
}
</style>
