<template>
<div> 
<v-container class="order" >
   
    <v-card-title class="inventory-top">
      Order History
      <v-spacer></v-spacer>
      <v-text-field
        v-model="search"
        append-icon="mdi-magnify"
        label="Search"
        single-line
        hide-details
      ></v-text-field>
    </v-card-title>
    <v-data-table
      :headers="headers"
      :items="products"
      :search="search"
    >
     <template v-slot:[`item.product`]="{ item }">
      <p v-for="dish in item.product" :key="dish.productid">{{dish.productname}}</p>
</template>
<template v-slot:[`item.price`]="{ item }">
      <p v-for="dish in item.product" :key="dish.productid">{{dish.price}}</p>
</template>
<template v-slot:[`item.quantity`]="{ item }">
      <p v-for="dish in item.product" :key="dish.productid">{{dish.quantity}}</p>
</template> 
<template v-slot:[`item.url`]="{ item }">

  <img width="100" height="100" :src="item.url" alt="hjh" srcset="">
</template> 
<template v-slot:[`item.Status`]="{ item }">
       {{item.status}}
   
      <!-- <v-icon
        small
        @click="deleteItem(item)"
      >
        mdi-delete
      </v-icon> -->
      <v-btn
  color="#fc9403"
  elevation="24"
  @click="deliver(item.orderId,item,item.date) "
  v-if="item.status=='Ordered'" style="color:white;width:fit-content;font-size:10px;font-weight:bold;padding:4px;"
>Delivered</v-btn>
    </template>
 <!-- <template v-slot:[`item.Actions`]="{ item }">
        
      <v-icon
        small
        @click="deleteItem(item)"
      >
        mdi-delete
      </v-icon>
    </template> -->
    </v-data-table>
  
</v-container>

 
</div>
</template>

<style>
     .order{
    margin-top: 60px;
    box-shadow: 1px 3px 9px 10px rgba(209, 201, 209, 0.82); 
    /* border-radius: 50px;  */
    height: max-content;
    }
    .inventory-top{
      margin-top:5%;
    }
</style>
<script src="../js/AdminOrderHistory.js"/>