 <template>
  <v-row justify="center">
    <div>
      <v-btn style="color:green!important" color="blue darken-1" text @click="check()">
        check
      </v-btn>
    </div>
    <div>{{ cartlist.length }}</div>
    <v-dialog v-model="dialog1" persistent max-width="400px">
      <v-card class="ordersummary">
        <v-card-title class="head">
          Placed Successfully
        </v-card-title>
        <v-card-text>
          <table>
            <tr>
              <td>Order Id</td>
              <td>:</td>
              <!-- <td> {{product[0].itemName}}</td> -->
            </tr>
            <tr>
              <td>User Id</td>
              <td>:</td>
              <!-- <td> {{product[0].quantity}}</td> -->
            </tr>
            <tr>
              <td>Date</td>
              <td>:</td>
              <!-- <td>product.orderid</td> -->
            </tr>
          </table>
        </v-card-text>
        <v-card-actions>
          <v-spacer></v-spacer>
          <v-btn color="green darken-1" text @click="dialog1 = false">
            ok
          </v-btn>
        </v-card-actions>
      </v-card>
    </v-dialog>
    <v-dialog v-model="dialog2" persistent max-width="600px">
      <v-card class="product">
        <v-card-title>
          <img
            src="https://s3-us-west-2.amazonaws.com/cbi-image-service-prd/modified/5542765a-126d-4456-93c8-d41ec129d81b.png"
            width="80px" height="80px">
          <span class="heading">Cloud Kitchens</span>
          <img src="https://icon-library.com/images/meal-icon-png/meal-icon-png-8.jpg" width="80px" height="80px"
            style="margin-left:auto">
        </v-card-title>
        <v-card-text>
          <v-container>

            <template class="simpletable">
              <v-simple-table>
                <template v-slot:default>
                  <thead>
                    <tr>
                      <!-- <th class="text-center">
            Item Id
          </th> -->
                      <th class="text-center">
                        Item Name
                      </th>
                      <th class="text-center">
                        Quantity
                      </th>
                      <th class="text-center">
                        Unit Price
                      </th>
                      <th class="text-center">
                        Total Price
                      </th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr v-for="item in  cartlist" :key="item.name">
                      <!-- <td>{{ item. itemName }}</td> -->
                      <td>{{  item.productname  }}</td>
                      <td>{{  item.quantity  }}</td>
                      <td>{{  item.price  }}</td>
                      <td>{{  item.price * item.quantity }}</td>
                    </tr>
                  </tbody>
                </template>
              </v-simple-table>
            </template>
            <v-card-text class="price">
              <table>
                <tr>
                  <td class="plabel">Total price</td>
                  <td>:</td>
                  <td class="pinput">Rs.{{ final.totalPrice }}</td>
                </tr>
                <tr>
                  <td class="plabel">GST(%)</td>
                  <td>:</td>
                  <td class="pinput">{{ final.discount }}%</td>
                </tr>
                <tr>
                  <td class="plabel">Net price</td>
                  <td>:</td>
                  <td class="pinput">Rs.{{ final.netprice }}</td>
                </tr>
              </table>
            </v-card-text>
            <v-card ref="form">
              <v-card-text class="userdetails">
                <!-- <v-card-title >
   Details
  </v-card-title> -->
                <table>
                  <tr>
                    <td class="plabel">Name</td>
                    <td>:</td>
                    <!-- <td class="uinput">{{localstorage.getItem(users.username)}}</td> -->
                  </tr>
                  <tr>
                    <td class="plabel">Contact no</td>
                    <td>:</td>
                    <!-- <td class="uinput">{{localstorage.getItem(users.mobno)}}</td> -->
                  </tr>
                </table>
                <!-- <v-text-field
            ref="name"
            v-bind=name
            :rules="[() => !!name || 'This field is required']"
            :error-messages="errorMessages"
            label="name"
             :disabled=true
            required
          ></v-text-field> -->
                <v-text-field v-model="num" :rules="[
                  value => (value && value.length == 10) || 'Invalid number',
                ]" label="Alternate no.(optional)" hide-details="auto"></v-text-field>
              </v-card-text>
            </v-card>
          </v-container>
        </v-card-text>
        <v-card-actions>
          <v-spacer></v-spacer>
          <v-btn style="color:red!important" color="blue darken-1" text @click="close()">
            close
          </v-btn>
          <v-btn style="color:green!important" color="blue darken-1" text @click="place()">
            Place
          </v-btn>

        </v-card-actions>
      </v-card>
    </v-dialog>


  </v-row>
</template>
<script src="../js/checkoutjs.js">

</script>

<style scoped>
* {
  font-family: 'Times New Roman', Times, serif;
}

.user {
  color: rgb(72, 5, 5);
  align-items: center;
}

.price {
  margin-left: 60%;
  width: 40%;
  color: black;
}

.price td {
  padding: 4px;

}

.plabel,
.uinput {
  float: left;
  font-weight: bold;
}

.pinput {
  float: left;
  margin-right: 10%;
  font-weight: bold;
}

.userdetails td {
  padding: 5px;
}

.head {
  color: green;
}

.ordersummary td {
  padding: 5px;
}

.product td,
th {
  text-align: center;
  color: black !important;
}

.heading {
  font-weight: bold;
}

@media only screen and (max-width : 300px) {
  .price {
    /* margin-left:0;
           width:100%; */
    /* font-size:3.5vw; */
    font: 4vw bold;
    color: black
  }

}

@media only screen and (max-width : 360px) and (min-width : 251px) {
  .price {
    margin-left: 10%;
    width: 90%;
  }

  .product img {
    width: 40px;
    height: 40px;
  }
}

@media only screen and (max-width : 458px) and (min-width : 361px) {
  .price {
    margin-left: 48%;
    width: 52%;
    padding: 0px;
    margin-right: 2px;
  }
}

@media only screen and (min-width : 458px) and (max-width : 564px) {
  .price {
    margin-left: 50%;
    width: 50%;
    padding: 0px;
    margin-right: 2px;
  }
}
</style>
