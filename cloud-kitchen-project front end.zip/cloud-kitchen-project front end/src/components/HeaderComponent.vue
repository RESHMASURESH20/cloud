<template>
  <div class="header">
    <v-app-bar 
      color="#f9f9f9"
      dense
      dark
    >
      <!-- <v-app-bar-nav-icon @click.stop="drawer = !drawer"></v-app-bar-nav-icon> -->

      <v-toolbar-title>Cloud-Kitchens</v-toolbar-title>

      <v-spacer></v-spacer>

      <!-- <v-btn icon>
        <v-icon>mdi-heart</v-icon>
      </v-btn>

      <v-btn icon>
        <v-icon>mdi-magnify</v-icon>
      </v-btn> -->
<v-menu
        left
        bottom
      >
        <template v-slot:activator="{ on, attrs }">
          <v-btn
            icon
            v-bind="attrs"
            v-on="on"
          >
            <v-icon>mdi-dots-vertical</v-icon>
          </v-btn>
        </template>

        <v-list>
          <v-list-item
          
          >
            <v-list-item-title @click="logout()">logout</v-list-item-title>
          </v-list-item>
        </v-list>
      </v-menu>
      <!-- <v-menu
        left
        bottom
      >
        <template v-slot:activator="{ on, attrs }">
          <v-btn
            icon
            v-bind="attrs"
            v-on="on"
          >
            <v-icon>mdi-dots-vertical</v-icon>
          </v-btn>
        </template>

        <v-list>
          <v-list-item
            v-for="n in 5"
            :key="n"
            @click="() => {}"
          >
            <v-list-item-title>Option {{ n }}</v-list-item-title>
          </v-list-item>
        </v-list>
      </v-menu> -->
     
    </v-app-bar>
      <v-sheet
    min-height="90vh"
    class="overflow-hidden"
    style="position: relative"
  >
    <!-- <v-container class="fill-height">
      <v-row
        align="center"
        justify="center"
      > -->
       <div class="">
          <router-view />
       </div>
        
      <!-- </v-row>
    </v-container> -->

    <v-navigation-drawer
      v-model="drawer"
      absolute
      temporary
    >
      <v-list-item>
        <v-list-item-avatar>
          <v-img src="https://t4.ftcdn.net/jpg/04/75/00/99/360_F_475009987_zwsk4c77x3cTpcI3W1C1LU4pOSyPKaqi.jpg"></v-img>
        </v-list-item-avatar>

        <v-list-item-content>
          <v-list-item-title>Admin</v-list-item-title>
        </v-list-item-content>
      </v-list-item>

      <v-divider></v-divider>

      <v-list dense>
        <v-list-item
          v-for="item in items" @click = "changePage(item.title)"
          :key="item.title"
          link
        >
          <v-list-item-icon>
            <v-icon>{{ item.icon }}</v-icon>
          </v-list-item-icon>

          <v-list-item-content>
            <v-list-item-title>{{ item.title }}</v-list-item-title>
          </v-list-item-content>
         
        </v-list-item>
      </v-list>
    </v-navigation-drawer>
  </v-sheet>

  </div>
</template>
<script src="../js/headerComponent.js">


</script>
<style >
/* .header
{
  background-color: aqua;
} */
*
{
  font-family: Arial;
}





.v-toolbar--dense .v-toolbar__content, .v-toolbar--dense .v-toolbar__extension {
    padding-top: 0;
    padding-bottom: 0;
    background-color: #fc9403;
}


.v-toolbar__content, .v-toolbar__extension {
    align-items: center;
    display: flex;
    position: relative;
    z-index: 0;
}


.v-toolbar__content, .v-toolbar__extension {
    padding: 4px 16px;
}

* {
    font-family: "Times New Roman", Times, serif;
}

* {
    padding: 0;
    margin: 0;
}

*, ::before, ::after {
    background-repeat: no-repeat;
    box-sizing: inherit;
}
</style>
