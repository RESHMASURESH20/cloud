<template>
      <v-row justify="center"> 
   <div>
    <v-btn @click="cancel()">cancel</v-btn>
   </div>
   <v-alert
      border="top"
      color="red lighten-2"
      dark
      v-if="dialog1"
    >
      Cancelled successfully
    </v-alert>
   <v-dialog
        v-model="dialog"
        persistent
        max-width="400px"
      >
      
      <v-card>
        <v-card-title class="text-h8">
          Are you sure?
        </v-card-title>
         <v-card-actions>
          <v-spacer></v-spacer>
          <v-btn
            color="green darken-1"
            text
            @click="yes()"
          >
             Yes
          </v-btn>
          <v-btn
            color="red darken-1"
            text
            @click="dialog = false"
          >
              No
          </v-btn>
        </v-card-actions>
      </v-card>
      </v-dialog>
    </v-row>
</template>

<script>
export default {
    data(){
        return{
          dialog:false,
          dialog1:false
        }
    },
methods:{
    cancel(){
        this.dialog=true
    },
    yes(){
        this.dialog=false;
        this.dialog1=true;
    }

}
}
</script>

<style>
.content{
    margin-top:5%!important;
    
}
</style>