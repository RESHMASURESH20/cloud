<template>
  <div class="cart">
    <!-- <div class="cart-title">CART</div> -->
    <div class="item-container">
      <!-- {{ cart.products.price}} -->
      <!-- {{cart.product}} -->
      <!-- {{carts[0].price}} -->
      <!-- {{carts[0].productname}} -->
      <CartitemComponent
        v-for="(data, index) in carts"
        :key="index"
        :items="data"
      />
     
     
     
    </div>
    <div class="down">
      <div class="totalamt">Total Amount:₹{{ returnamount() }}</div>

      <div class="order-button">
        <div class="warnings" v-if="stockstatus()">
          *remove unavailable items to continue
        </div>

        <div class="warnings" v-if="cartstatus()">
          *add any item to the cart to continue
        </div>

        <input
          type="button"
          class="button-6"
          value="CHECKOUT"
          v-if="stockstatus() || cartstatus()"
        />

        <input
          type="button"
          class="button-5"
          value="CHECKOUT"
          @click="check()"
          v-else
          :disabled="!carts.length"
        />
      </div>
    </div>
    <!-- <div>{{ cartlist.length }}</div> -->
    <!-- <div>{{ orderlist.length }}</div> -->
    <v-dialog v-model="dialog1" persistent max-width="400px">
      <v-card class="ordersummary">
        <v-card-title class="head">
          Thank you for ordering
          <img
            src="https://media.istockphoto.com/vectors/food-related-kitchen-typography-quote-bon-appetit-vintage-vector-vector-id528502912"
            style="margin-left: auto"
          />
        </v-card-title>
        <v-card-text>
          <table>
            <tr>
              <td>Order Id</td>
              <td>:</td>
              <td>{{ orderlist.orderId }}</td>
            </tr>
            <tr>
              <td>User Id</td>
              <td>:</td>
              <td>{{ orderlist.userId }}</td>
            </tr>
            <tr>
              <td>Date</td>
              <td>:</td>
              <td>{{ orderlist.date }}</td>
            </tr>
          </table>
        </v-card-text>
        <v-card-actions>
          <v-spacer></v-spacer>
          <v-btn color="green darken-1" text @click="ok()"> ok </v-btn>
        </v-card-actions>
      </v-card>
    </v-dialog>

    <v-dialog v-model="dialog2" persistent max-width="600px">
      <v-card class="product">
        <v-card-title>
          <img
            src="https://s3-us-west-2.amazonaws.com/cbi-image-service-prd/modified/5542765a-126d-4456-93c8-d41ec129d81b.png"
            width="80px"
            height="80px"
          />
          <span class="heading">Cloud Kitchens</span>
          <img
            src="https://icon-library.com/images/meal-icon-png/meal-icon-png-8.jpg"
            width="80px"
            height="80px"
            style="margin-left: auto"
          />
        </v-card-title>
        <v-card-text>
          <template class="simpletable">
            <v-simple-table>
              <template v-slot:default>
                <thead>
                  <tr>
                    <th class="text-center">Item Name</th>
                    <th class="text-center">Quantity</th>
                    <th class="text-center">Offer</th>
                    <th class="text-center">Unit Price</th>
                    <th class="text-center">Total Price</th>
                  </tr>
                </thead>
                <tbody>
                  <tr v-for="item in carts" :key="item.name">
                    <!-- <td>{{ item. itemName }}</td> -->
                    <td>{{ item.productname }}</td>
                    <td>{{ item.quantity }}</td>
                    <td>{{ item.offer }}%</td>
                    <td>{{ item.price }}</td>
                    <td>
                      ₹{{
                        (
                          item.price * item.quantity -
                          (item.price * item.quantity * item.offer) / 100
                        ).toFixed(0)
                      }}
                    </td>
                  </tr>
                </tbody>
              </template>
            </v-simple-table>
          </template>
          <v-container>
            <v-card-text class="price">
              <table>
                <tr>
                  <td class="plabel">Total price</td>
                  <td>:</td>
                  <td class="pinput">₹{{ final.totalPrice.toFixed(0) }}</td>
                </tr>
                <tr>
                  <td class="plabel">GST(%)</td>
                  <td>:</td>
                  <td class="pinput">{{ final.discount }}%</td>
                </tr>
                <tr>
                  <td class="plabel">Net price</td>
                  <td>:</td>
                  <td class="pinput">₹{{ final.netprice.toFixed(0) }}</td>
                </tr>
              </table>
            </v-card-text>
            <v-card ref="form">
              <v-card-text class="userdetails">
                <table>
                  <tr>
                    <td class="plabel">Name</td>
                    <td>:</td>
                    <td class="uinput">{{ nameu }}</td>
                  </tr>
                  <tr>
                    <td class="plabel">Contact no</td>
                    <td>:</td>
                    <td class="uinput">{{ phoneu }}</td>
                  </tr>
                </table>
                <v-text-field
                  v-model="num"
                  :rules="[
                    (value) =>
                      (value && value.length == 10) || 'Invalid number',
                  ]"
                  label="Alternate no.(optional)"
                  hide-details="auto"
                ></v-text-field>
              </v-card-text>
            </v-card>
          </v-container>
        </v-card-text>
        <v-card-actions>
          <v-spacer></v-spacer>
          <v-btn
            style="color: red !important"
            color="blue darken-1"
            text
            @click="close()"
          >
            cancel
          </v-btn>
          <v-btn
            style="color: green !important"
            color="blue darken-1"
            text
            @click="place()"
          >
            Place
          </v-btn>
        </v-card-actions>
      </v-card>
    </v-dialog>
  </div>
</template>

<script>
import CartitemComponent from "./CartitemComponent.vue";
import { placeorder } from "../service/cart.service";
import { mapGetters } from "vuex";
export default {
  data() {
    return {
      success: true,
      num: "",
      flag: false,
      dialog2: false,
      dialog1: false,
      userid: localStorage.getItem("userid"),
      nameu: localStorage.getItem("name"),
      usernameu: localStorage.getItem("username"),
      phoneu: localStorage.getItem("phone"),
      order: {
        userId: 0,
        name: "",
        userName: "",
        phonenumber: "",
        alternativenumber: "",
        totalprice: 0,
        netprice: 0,
        date: "",
        status: "Ordered",
        product: {},
      },
    };
  },
  components: {
    CartitemComponent,
  },
  methods: {
    returnamount() {
      let total = 0;

      this.carts.forEach((element) => {
        total +=
          (element.price - (element.offer / 100) * element.price) *
          element.quantity;
      });

      return total.toFixed(0);
    },

    cartstatus() {
      let flag = false;

      if (this.carts.length == 0) flag = true;

      return flag;
    },

    stockstatus() {
      let flag = false;

      this.carts.forEach((element) => {
        if (element.existingquantity == "Out Of Stock") flag = true;
      });

      return flag;
    },
    check() {
      this.dialog2 = true;
    },
    place() {
      console.log("Post", this.order);
      (this.order.userId = this.userid),
        (this.order.name = this.nameu),
        (this.order.userName = this.usernameu),
        (this.order.phonenumber = this.phoneu),
        (this.order.alternativenumber = this.num),
        (this.order.totalprice = this.final.totalPrice),
        (this.order.netprice = this.final.netprice),
        (this.order.date =
          new Date().toLocaleDateString() +
          " " +
          new Date().toLocaleTimeString()),
        (this.order.product = this.carts);
      console.log("Post", this.order);
      //  setTimeout(()=>((this.$store.dispatch( 'getsuccessFlag'))),10000)

      placeorder({
        order: this.order,
        success: ({ data }) => {
          console.log(data);
          (this.num = ""), (this.dialog2 = false);
          this.dialog1 = true;
          //  this.$store.dispatch('getcartitemsfromservice',localStorage.getItem("userid"))

          this.$store.dispatch("GET_ORDER", data);
        },
        error: (e) => {
          console.log(e);
        },
      });
    },
    close() {
      this.dialog2 = false;
      this.num = "";
    },
    ok() {
      this.dialog1 = false;
      this.carts.length = 0;
    },
  },
  computed: {
    ...mapGetters({
      carts: "getCartlist",
      final: "getTotalPrice",
      orderlist: "getorder",
      successFlag: "getFlag",
    }),
  },

  created() {
    console.log("created");
    this.$store.dispatch("getuseridfromservice", localStorage.getItem("users"));
    // console.log('success flag',this.$store.state.cart.success)
    console.log(this.successFlag);
  },
};
</script>

<style>
.item-container {
  height: 370px;

  overflow: scroll;
}

.warnings {
  font-size: 10px;

  color: red;

  /* background-color:white; */
}



.cart {
  /* margin-top:10px; */

  height: 590px;

  margin-top: 120px;

  margin-right: 20px;

  width: 320px;

  /* margin-left:1100px; */

  background-color: white;
  box-shadow: rgba(149, 157, 165, 0.2) 0px 8px 24px;
  padding: 10px;

  border-radius: 20px;

  top: 0;

  right: 0;

  position: fixed;
}

@media only screen and (max-width: 770px) {
  .cart {
    /* width: 80%; */
    margin-top:200px;
    position: absolute;
    left:10;
    /* float:left; */
    /* margin-left:0px; */
  }

  .checkout {
    width: 50px;

    font-size: 7px;
  }
}

@media only screen and (max-width: 280px) {
.cart
{
   
   margin-left:40px;
   width:240px;
   

}

}
.down {
  border-top-color: grey;

  border-top-style: solid;

  margin-top: 60px;
}

.order-button {
  margin-top: 20px;

  margin-left: 85px;
}



/* CSS */
.button-6 {
  align-items: center;
  background-color: #FFFFFF;
  border: 1px solid rgba(0, 0, 0, 0.1);
  border-radius: .25rem;
  box-shadow: rgba(0, 0, 0, 0.02) 0 1px 3px 0;
  box-sizing: border-box;
  color: rgba(0, 0, 0, 0.85);
  cursor: pointer;
  display: inline-flex;
  font-family: system-ui,-apple-system,system-ui,"Helvetica Neue",Helvetica,Arial,sans-serif;
  font-size: 16px;
  font-weight: 600;
  justify-content: center;
  line-height: 1.25;
  margin: 0;
  min-height: 3rem;
  padding: calc(.875rem - 1px) calc(1.5rem - 1px);
  position: relative;
  text-decoration: none;
  transition: all 250ms;
  user-select: none;
  -webkit-user-select: none;
  touch-action: manipulation;
  vertical-align: baseline;
  width: auto;
}





.button-5{
  align-items: center;
  background-clip: padding-box;
  background-color: #fa6400;
  border: 1px solid transparent;
  border-radius: .25rem;
  box-shadow: rgba(0, 0, 0, 0.02) 0 1px 3px 0;
  box-sizing: border-box;
  color: #fff;
  cursor: pointer;
  display: inline-flex;
  font-family: system-ui,-apple-system,system-ui,"Helvetica Neue",Helvetica,Arial,sans-serif;
  font-size: 16px;
  font-weight: 600;
  justify-content: center;
  line-height: 1.25;
  margin: 0;
  min-height: 3rem;
  padding: calc(.875rem - 1px) calc(1.5rem - 1px);
  position: relative;
  text-decoration: none;
  transition: all 250ms;
  user-select: none;
  -webkit-user-select: none;
  touch-action: manipulation;
  vertical-align: baseline;
  width: auto;
}

.button-5:hover,
.button-5:focus {
  background-color: #fb8332;
  box-shadow: rgba(0, 0, 0, 0.1) 0 4px 12px;
}

.button-5:hover {
  transform: translateY(-1px);
}

.button-5:active {
  background-color: #c85000;
  box-shadow: rgba(0, 0, 0, .06) 0 2px 4px;
  transform: translateY(0);
}


* {
  font-family: "Times New Roman", Times, serif;
}

.user {
  color: rgb(72, 5, 5);

  align-items: center;
}

.price {
  margin-left: 60%;

  width: 40%;

  color: black;
}

.price td {
  padding: 4px;
}

.plabel,
.uinput {
  float: left;

  font-weight: bold;
}

.pinput {
  float: left;

  margin-right: 10%;

  font-weight: bold;
}

.userdetails td {
  padding: 5px;
}

.head {
  color: green;
}

.totalamt {
  margin-left: 10px;
}

.ordersummary td {
  padding: 5px;
}

.product td,
th {
  text-align: center;

  color: black !important;
}

.heading {
  font-weight: bold;
}

@media only screen and (max-width: 300px) {
  .price {
    /* margin-left:0;

           width:100%; */

    /* font-size:3.5vw; */

    font: 4vw bold;

    color: black;
  }

  .product img {
    width: 30px;

    height: 30px;
  }
}

@media only screen and (max-width: 360px) and (min-width: 251px) {
  .price {
    margin-left: 10%;

    width: 90%;
  }

  .product img {
    width: 30px;

    height: 30px;
  }
}

@media only screen and (max-width: 458px) and (min-width: 361px) {
  .price {
    margin-left: 48%;

    width: 52%;

    padding: 0px;

    margin-right: 2px;
  }

  .product img {
    width: 30px;

    height: 30px;
  }
}

@media only screen and (min-width: 458px) and (max-width: 564px) {
  .price {
    margin-left: 50%;

    width: 50%;

    padding: 0px;

    margin-right: 2px;
  }
}
</style>