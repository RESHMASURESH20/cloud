<template>
<div> 
<v-container class="order" >
   <v-card
      class="d-flex flex-row-reverse"
      :color="$vuetify.theme.dark ? 'grey darken-3' : 'grey lighten-4'"
      flat
      tile
    >
      <v-card
        
        class="pa-2"
        outlined
        tile>
        <v-btn   class="btn1"  @click="dialog=true" color="#fc9403" style="color:white"> Add product
   </v-btn>
    
      </v-card>
            <v-card
        
        class="pa-2"
        outlined
        tile>
      
      <v-btn class="btn2"  color="#fc9403" @click="order()" style="color:white"> Order History</v-btn>
      </v-card>
    </v-card>
  <div class="button1">
   <!-- <v-btn absolute right  class="btn1"  @click="dialog=true" color="primary">
    Add product
   </v-btn> -->
    <!-- <v-btn absolute right  class="btn2"  color="primary" @click="order()">Order History
   </v-btn> -->
  </div>
    <v-card-title class="inventory-top">
      Inventory Details
      <v-spacer></v-spacer>
      <v-text-field
        v-model="search"
        append-icon="mdi-magnify"
        label="Search"
        single-line
        hide-details
      ></v-text-field>
    </v-card-title>
    <v-data-table
      :headers="headers"
      :items="products"
      :search="search"
       
    >
    
<!-- <template v-slot:[`item.Availablity`]="{ item }">
  <v-btn v-if
</template> -->
<template v-slot:[`item.url`]="{ item }">
  <img width="100" height="100" :src="item.url" alt="hjh" srcset="">
</template>
 


<template v-slot:[`item.Actions`]="{ item }">
         <v-icon
        small
        @click="dialog3=true,editItem(item)"
        >
        mdi-pencil
        
      </v-icon>
       <!-- @click="dialog3=true" -->
      <v-icon
        small
        @click="deleteItem(item)"
      >
        mdi-delete
      </v-icon>
    </template>
    </v-data-table>
</v-container>
 

<v-row justify="center">
    <v-dialog
      v-model="dialog3"
      persistent
      max-width="900">
      <v-card>
        <v-card-title class="text-h5">
         Edit Products
        </v-card-title>
        <v-card-text>
          <v-row>
              <v-col cols="12" lg="4" md="12" sm="12">
  <v-text-field
      label="Food Name"
      v-model="product.foodname"
     :rules="rules"
    ></v-text-field>
  </v-col>
   <v-col cols="12" lg="4" md="12" sm="12">
  <v-select
    :items="['Non Vegetarian', 'Vegetarian']"
       v-model="product.category"
    label="Category"
  ></v-select>
  </v-col>
  <!-- <v-col cols="12" lg="4" md="12" sm="12">
  <v-text-field
      label="Item Type"
        v-model="product.itemType"
    ></v-text-field>
    
  </v-col> -->
   <v-col cols="12" lg="4" md="12" sm="12">
  <v-text-field type="number"
      label="Price"
        v-model="product.price"
         :rules="pricerules"
    ></v-text-field>
  </v-col>
   
  <v-col cols="12" lg="4" md="12" sm="12">
    <v-text-field
       v-model="product.cuisine"
      label="Cuisine"
     
    ></v-text-field>
    </v-col>
     
    <v-col cols="12" lg="4" md="12" sm="12">
  <v-select
    :items="['In Stock', 'Out Of Stock']"
       v-model="product.stockCount"
    label="Stock"
  ></v-select>
  </v-col>
    
     
      <v-col cols="12" lg="4" md="12" sm="12">
    <v-text-field
      label="Offer"
         v-model="product.offer"
     :rules="offerrules"
    ></v-text-field>
    </v-col>
    
    
    <v-col cols="12" lg="12" md="12" sm="12">
    <v-text-field
      label="Image"
         v-model="product.url"
     
    ></v-text-field>
    </v-col>

      <v-col cols="12" lg="12" md="12" sm="12">
         <v-textarea  solo dense filled
          name="input-7-4"
          label="Description"
        v-model="product.description"
        ></v-textarea>
    </v-col>
  </v-row>
   <span class="errortext">{{this.error}}</span>
        </v-card-text> 
        <v-card-actions>
          <v-spacer></v-spacer>
          <v-btn
            color="danger"
            text
            @click="dialog3 = false"
          >
            cancel
          </v-btn>
          <v-btn
            color="success"
            text
            @click="editsave()"
           >
           save
          </v-btn>
        </v-card-actions>
      </v-card>
    </v-dialog>
    <v-dialog
      v-model="dialog2"
      persistent
      max-width="900"
    >
    <!-- <EditProductComponent /> -->
    </v-dialog>
  </v-row>





 <v-row justify="center">
    <v-dialog
      v-model="dialog"
      persistent
      max-width="900">
      <v-card>
        <v-card-title class="text-h5">
         Add Products
        </v-card-title>
        <v-card-text>
          <v-row>
              <v-col cols="12" lg="4" md="12" sm="12">
  <v-text-field
      label="Food Name"
      v-model="product.foodname"
     :rules="rules"
    ></v-text-field>
  </v-col>
   <v-col cols="12" lg="4" md="12" sm="12">
  <v-select
    :items="['Non Vegetarian', 'Vegetarian']"
       v-model="product.category"
    label="Category"
  ></v-select>
  </v-col>
  <!-- <v-col cols="12" lg="4" md="12" sm="12">
  <v-text-field
      label="Item Type"
        v-model="product.itemType"
    ></v-text-field>
    
  </v-col> -->
   <v-col cols="12" lg="4" md="12" sm="12">
  <v-text-field
      label="Price"
        v-model="product.price"
         :rules="pricerules"
    ></v-text-field>
  </v-col>
   
  <v-col cols="12" lg="4" md="12" sm="12">
    <v-text-field
       v-model="product.cuisine"
      label="Cuisine"
     
    ></v-text-field>
    </v-col>
      <v-col cols="12" lg="4" md="12" sm="12">
  <v-select
    :items="['In Stock', 'Out Of Stock']"
       v-model="product.stockCount"
    label="Stock"
  ></v-select>
  </v-col>
    
   
     <!-- <v-col cols="12" lg="4" md="12" sm="12">
    <v-text-field
      label="Stock count"
         v-model="product.stockCount"
      :rules="stockrules"
    ></v-text-field>
    </v-col> -->
     
      <v-col cols="12" lg="4" md="12" sm="12">
    <v-text-field
      label="Offer"
         v-model="product.offer"
     :rules="offerrules"
    ></v-text-field>
    </v-col>
    
    
    <v-col cols="12" lg="12" md="12" sm="12">
    <v-text-field
      label="Image"
         v-model="product.url"
     
    ></v-text-field>
    </v-col>

      <v-col cols="12" lg="12" md="12" sm="12">
         <v-textarea  solo dense filled
          name="input-7-4"
          label="Description"
        v-model="product.description"
        ></v-textarea>
    </v-col>
  </v-row>
   <span class="errortext">{{this.error}}</span>
        </v-card-text> 
        <v-card-actions>
          <v-spacer></v-spacer>
          <v-btn
            color="danger"
            text
            @click="dialog = false"
          >
            cancel
          </v-btn>
          <v-btn
            color="success"
            text
            @click="saveInventory()">
           save
          </v-btn>
        </v-card-actions>
      </v-card>
    </v-dialog>
    <v-dialog
      v-model="dialog2"
      persistent
      max-width="900"
    >
    <!-- <EditProductComponent /> -->
    </v-dialog>
  </v-row>

  <!-- <v-dialog
  :items="products"
      v-model="dialog2"
      width="900">
      <template v-slot:activator="{ on, attrs }" >
        <v-btn
          color="red lighten-2"
          dark
          v-bind="attrs"
          v-on="on"
        >
          Click Me
        </v-btn>
      </template>

      <v-card>
        <v-card-title class="text-h5 grey lighten-2">
          Edit Products
        </v-card-title>

        <v-card-text>
          <v-row>
              <v-col cols="12" lg="4" md="12" sm="12">
                <v-text-field
               label="Item Name"
               v-model="product.foodname"
               :rules="rules"
                 ></v-text-field>
              </v-col>
             <v-col cols="12" lg="4" md="12" sm="12">
                 <v-select
                 :items="['Non Vegetarian', 'Vegetarian']"
                v-model="product.category"
                label="Category"
                 ></v-select>
                </v-col>
                 <v-col cols="12" lg="4" md="12" sm="12">
              <v-text-field
               label="Price"
               v-model="product.price"
                :rules="pricerules"
              ></v-text-field>
              </v-col>
   
              <v-col cols="12" lg="4" md="12" sm="12">
              <v-text-field
               v-model="product.cuisine"
              label="Cuisine" 
               ></v-text-field>
               </v-col>
               <v-col cols="12" lg="4" md="12" sm="12">
    <v-text-field
      label="Stock count"
         v-model="product.stockCount"
      :rules="stockrules"
    ></v-text-field>
    </v-col>
     
      <v-col cols="12" lg="4" md="12" sm="12">
    <v-text-field
      label="Offer"
         v-model="product.offer"
     :rules="offerrules"
    ></v-text-field>
    </v-col>
    
    
    <v-col cols="12" lg="12" md="12" sm="12">
    <v-text-field
      label="Image"
         v-model="product.url"
     
    ></v-text-field>
    </v-col>

      <v-col cols="12" lg="12" md="12" sm="12">
         <v-textarea  solo dense filled
          name="input-7-4"
          label="Description"
        v-model="product.description"
        ></v-textarea>
    </v-col>
           </v-row>
          </v-card-text>

        <v-divider></v-divider>

        <v-card-actions>
          <v-spacer></v-spacer>
          <v-btn
            color="primary"
            text
            @click="dialog2 = false"
          >
            Cancel
          </v-btn>
          <v-btn
            color="primary"
            text
            @click="editItem()"
          >
            Edit
          </v-btn>
        </v-card-actions>
      </v-card>
    </v-dialog> -->
     <!-- <sweetalert-icon v-if="del" icon="success" /> -->
  <v-alert
  dismissible
  elevation="24"
  type="success"
  v-if="succes"
>product Added successfully</v-alert>
<v-alert
  color="red"
  dismissible
  type="success"
  v-if="del"
>Product deleted successfully</v-alert>

</div>
</template>

<style>
 .v-application .grey.lighten-4 {
      background-color: white !important;
 }
 .pa-2.v-card.v-sheet.v-sheet--outlined.theme--light.rounded-0 {
  border:0px;
}
/* .btn1{
margin-right:12%;
margin-top:3%;
margin-bottom:2%;
}
 button.btn2.v-btn.v-btn--absolute.v-btn--is-elevated.v-btn--has-bg.v-btn--right.theme--light.v-size--default.primary {
margin-right: 26%;
margin-top: 4%;
} */
     .order{
    margin-top: 20px;
    box-shadow: 1px 3px 9px 10px rgba(209, 201, 209, 0.82); 
    /* border-radius: 50px;  */
    height: max-content;
    }
    .inventory-top{
      margin-top:5%;
    }
    .errortext{color: red;
text-align: center;}
.button1{
  width:100%;
}
 @media screen and(max-width:1000px) {
   button.btn2.v-btn.v-btn--absolute.v-btn--is-elevated.v-btn--has-bg.v-btn--right.theme--light.v-size--default.primary {
margin-right: 30%;
}
 }
</style>
<script src="../js/inventoryComponent.js"/>