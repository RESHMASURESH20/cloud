<template>
  <div class="cart-item">

    <div class="cart-image">
      <img :src="items.imageurl" />
    </div>

    <div class="cart-info">
      <div class="left">
        <div class="item-name">
          {{ items.productname }}
        </div>

        <div class="cart-price">
          <!-- ₹{{ newprice.toFixed(0) * items.quantity }} -->

          <!-- {{items.existingquantity}} -->
        </div>

        <div class="quantity">
          x{{ items.quantity }}
          <!-- {{items.existingquantity}} -->

          <!-- {{items.productid}} -->

          <!-- <div class="alert" v-if="items.existingquantity == 'Out Of Stock'">
            OUT OF STOCK
          </div> -->
        </div>
      </div>

      <div class="delete-button" @click="deletefromcart()">
        <ion-icon class="icon" name="trash-outline"></ion-icon>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  props: {
    items: {
      type: Object,
      default: () => {},
    },
  },
  data() {
    return {
      newprice: this.items.price - (this.items.offer / 100) * this.items.price,
    };
  },

  methods: {
    deletefromcart() {
      let payload = {
        userid: localStorage.getItem("userid"),

        productid: this.items.productid,
      };

      this.$store.dispatch("deleteitemservice", payload);
    },
  },
};
</script>

<style scoped>
.item-name {
  font-size: 13px;

  font-style: bold;

  /* fon */
}

.cart-price {
  font-size: 13px;
}

.delete-button {
  margin-top: 35px;

  width: 10px;
}

.cart-item {
 

  /* border:none; */

  background-color: #f9f9f9;

  display: flex;

  flex-wrap: wrap;

  flex-direction: row;

  margin: 10px;

  border-radius: 15px;

  height: 85px;

  font-family:sans-serif;
}

.icon:hover {
  color: red;
}

.left {
  display: flex;

  flex-direction: column;

  width: 160px;

  padding: 10px;

  height: 40px;
}

.quantity {
  margin-left: 0px;

  display: flex;

  flex-wrap: wrap;

  flex-direction: row;
}

.cart-info {
  display: flex;

  flex-direction: row;

  flex-wrap: wrap;

  height: 70px;

  /* justify-content: space-between; */
}

.alert {
  color: red;

  background-color: rgb(237, 169, 169);

  font-family: arial;

  font-size: 10px;

  margin-left: 80px;

  padding: 3px;

  border-radius: 5px;

  height: 20px;
}

img {
  height: 70px;

  width: 70px;

  border-radius: 15px;

  margin: 5px;
}

@media only screen and (max-width: 280px) {
   .left {
    width: 80px;
  }
}

@media only screen and (max-width: 770px) {
  .item-name {
    font-size: 11px;

    /* fon */
  }

  .cart-price {
    font-size: 11px;
  }

  .quantity {
    font-size: 11px;
  }

  .alert {
    color: red;

    background-color: rgb(237, 169, 169);

    font-family: arial;

    font-size: 5px;

    margin-left: 80px;

    padding: 2px;

    border-radius: 5px;

    height: 20px;
  }
}
</style>