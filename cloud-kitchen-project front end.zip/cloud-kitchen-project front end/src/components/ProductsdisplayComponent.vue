
<template>
   <div>
   
   <SearchComponent/>
  <div class="container-product">
  
    <!-- <div class="search-element">

       <div class="search-text">

         <input type="text" placeholder="enter food item" v-model="searchtext">

       </div>

       <div class="search-button">

         <ion-icon name="search-outline" size="large" @click="search()"></ion-icon>

       </div>  

        <div >

          <input class="clear-search" type="button" value="CLEAR SEARCH" @click="clear()">

       </div>  



       <ProductscontainerComponent/>

    </div> -->
        <ProductscontainerComponent/>
  </div>
</div>
</template>





<script>
import ProductscontainerComponent from "./ProductscontainerComponent";
import SearchComponent from "./SearchComponent";
export default {
    
    components:
    {
        ProductscontainerComponent,
        SearchComponent 
    },

    data()
    {
        return{
              searchtext:'',
        }
    },

    methods:
    {
        search()
        {   
            //alert(this.searchtext);
            this.$store.dispatch('searchfooditemsfromservice',this.searchtext);
        },
        clear()

        {

           this.$store.dispatch('getfooditemsfromservice');

        },
    }
}
</script>

<style scoped>
.clear-search

{

  border:none;

  font-family: arial;

   width:150px;

}

input[type="text"]

{

  border-radius:3px;

  background-color: white;

  padding:3px;

  height:30px;

}



/* input[type="button"]

{

  border-radius:3px;

  border-color:orange;

  color:rgb(242, 190, 95);

  background-color:white;

  padding:3px;

 

  font-size:13px;

  height:30px;

} */



.search-text

{

  margin-right:10px;

}

.container-product

{

     display:flex;

    flex-wrap:wrap;

    flex-direction:row; 

    justify-content: center;

    margin-right:400px;

    /* width:980px; */

   

}



.search-element

{    

    display: flex;

    flex-wrap:wrap;

    flex-direction:row;

    justify-content:center;

    margin-top:20px;

    margin-left:55px;

}



input[type="text"]

{

   width:400px;

}



@media only screen and (max-width : 1124px){

  input[type="text"]

{

   width:150px;

}



.clear-search

{

  border:none;

  font-family: arial;

   width:80px;

   font-size:10px;

}



}
</style>