 <template>
  <div class="product-card">
    <div class="category1" v-if="item.category=='vegetarian'">
        VEG
    </div>
    <div class="category2" v-else>
        NON-VEG
    </div>

    <div class="product-image">
      <img class="image" :src="image" alt="imgh" />
    </div>
    <br />

    <div class="product-name">
      {{ item.foodname }}
    </div>
    <br />

    <div class="product-info">
      <!-- <div class="product-price"> -->

      <div class="oldprice">Rs.{{ item.price }}</div>

      <div class="newprice">Rs.{{ newprice.toFixed(0) }}</div>

      <!-- </div> -->

      <div v-if="item.stockCount == 'Out Of Stock'">
        <div>
          <input class="outofstock" type="button" value="Out of stock" />
        </div>
      </div>

      <div v-else>
        <div class="add-cart" v-if="checkproduct()">
          <input
            type="button"
            class="addtocart"
            value="Add to cart"
            @click="add()"
          />
        </div>

        <div class="added" v-else>
          <input
            type="button"
            class="dec"
            value="-"
            @click="decrease()"
          /><input type="button" class="quan" :value="getquantity()" /><input
            class="inc"
            type="button"
            value="+"
            @click="increase()"
          />
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { mapGetters } from "vuex";

export default {
  props: {
    item: {
      type: Object,

      default: () => {},
    },
  },

  data() {
    return {
      image: this.item.url,

      quantity: 2,

      flag: true,

      newprice: this.item.price - (this.item.offer / 100) * this.item.price,
    };
  },

  computed: {
    ...mapGetters({
      cartitemlist: "getCartlist",
    }),
  },

  //    beforeMounted()

  //    {

  //      this.checkproduct()

  //    },

  methods: {
    getquantity() {
      let num = 0;

      console.log("get quantity called");

      this.cartitemlist.map((data) => {
        // console.log(data.productid)

        // console.log(this.item.foodId)

        //  console.log("hello")

        if (data.productid == this.item.foodId) {
          console.log("equal");

          console.log(data.quantity);

          num = data.quantity;

          // num=this.item.quantity;
        }
      });

      return num;
    },

    checkproduct() {
      let f = true;

      console.log("called");

      this.cartitemlist.map((data) => {
        // console.log(data.productid)

        // console.log(this.item.foodId)

        //  console.log("hello")

        if (data.productid == this.item.foodId) {
          // console.log("equals");

          this.quantity = this.item.quantity;

          f = false;
        }
      });

      return f;
    },

    add() {
      this.flag = false;

      // this.quantity+=1;

      let payload = {
        userid: localStorage.getItem("userid"),

        products: [
          {
            productid: this.item.foodId,

            // productname:this.item.foodname,

            //  price:this.item.price,

            quantity: 1,
          },
        ],
      };

      this.$store.dispatch("insertcartitemstoservice", payload);

      this.$store.dispatch(
        "getcartitemsfromservice",
        localStorage.getItem("userid")
      );

      //  this.$store.dispatch('getcartitemsfromservice',localStorage.length("users"));

      this.checkproduct();

      this.getquantity();
    },

    increase() {
      let payload = {
        // userid:'123456',

        userid: localStorage.getItem("userid"),

        productid: this.item.foodId,
      };

      this.getquantity();

      // this.$store.dispatch('getcartitemsfromservice',localStorage.getItem("userid"));

      this.$store.dispatch("increaseservice", payload);

      this.quantity += 1;

      this.checkproduct();
    },

    decrease() {
      let payload = {
        userid: localStorage.getItem("userid"),

        productid: this.item.foodId,
      };

      this.$store.dispatch("decreaseservice", payload);

      this.$store.dispatch(
        "getcartitemsfromservice",
        localStorage.getItem("userid")
      );

      // this.quantity-=1;

      // if(this.quantity==0)

      //  this.flag=true;

      this.checkproduct();

      this.getquantity();
    },
  },
};
</script>

<style scoped>

.category1
{
     border-style:solid;
     border-color:green;
     color:green;
     width:40px;
     font-family: sans-serif;
     font-size:10px;
     border-radius:3px;
      margin-left:275px;
      margin-bottom:50px;
}

.category2
{
     border-style:solid;
     border-color:red;
     color:red;
     width:80px;
     font-family: sans-serif;
     font-size:10px;
      border-radius:3px;
      margin-left:230px;
      margin-bottom:50px;
}

.product-info {
  display: flex;

  flex-wrap: wrap;

  flex-direction: row;
}

.newprice {
  margin-top: 5px;

  margin-left: 10px;

  color: black;

  font-size: new;
}

.oldprice {
  margin-top: 5px;

  margin-left: 30px;

  color: grey;
}

.add-cart {
  margin-left: 40px;
}

.added {
  margin-left: 40px;
}

.addtocart {
  border-radius: 7px;

  padding: 5px;

  border: none;

  background-color: lightgrey;

  font-family: arial;

  font-size: 15px;
}

.addtocart:hover {
  background-color: rgb(205, 203, 203);
}

.outofstock {
  border-radius: 7px;

  padding: 5px;

  border: none;

  background-color: lightgrey;

  font-family: arial;

  font-size: 15px;

  margin-left: 40px;
}

.dec {
  padding: 3px;

  border: none;

  border-top-left-radius: 5px;

  border-bottom-left-radius: 5px;

  width: 30px;

  background-color: lightgrey;
}

.dec:hover {
  background-color: rgb(205, 203, 203);
}

.inc:hover {
  background-color: rgb(205, 203, 203);
}

.product-name {
  font-family: arial;
}

.product-price {
  font-family: arial;

  color: grey;

  font-size: 7px;
}

.inc {
  padding: 3px;

  border: none;

  border-top-right-radius: 5px;

  border-bottom-right-radius: 5px;

  width: 30px;

  background-color: lightgrey;
}
.quan {
  width: 30px;

  padding: 3px;

  border: none;

  font-family: arial;
}

.oldprice {
  text-decoration: line-through;

  font-family: arial;
}

.image {
  border-radius: 10px;

  height: 150px;

  width: 200px;

  margin-left: 0px;

  /* margin-top: px; */
}

.product-card {
  display: flex;

  flex-wrap: wrap;

  flex-direction: column;

  text-align: center;

  justify-content: center;
   
    background-color: white;
  box-shadow: rgba(149, 157, 165, 0.2) 0px 8px 24px;
  height: 400px;

  width: 31.3%;


  border-radius: 10px;

  margin: 10px;
}

@media only screen and (max-width: 1428px) {
  .product-card {
    width: 47%;
  }
}

@media only screen and (max-width: 1124px) {
  .product-card {
    width: 45%;
  }
}

@media only screen and (max-width: 1080px) {
  .product-card {
    width: 100%;
  }
}

@media only screen and (max-width: 770px) 
{
     .image {
  height: 120px;

  width: 150px;

  margin-left: 0px;
}

.product-info
{
    flex-direction: column;
}

.category1
{
    margin-left:175px;

}

.category2
{
    margin-left:110px;

}

.product-card {
    /* margin:0px; */
    width: 240px;
  }

  

}
</style>