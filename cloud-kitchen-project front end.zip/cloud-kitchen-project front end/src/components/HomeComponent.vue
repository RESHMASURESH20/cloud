<template>
   <div>
     <UserHeaderComponent/>
     <div>
       <router-view/>
     </div>
     
      <FooterComponent/>
   </div>

</template>
<script src="../js/home.js">

</script>

<style >
*
{
   font-family: arial
}
</style>