<template>
  <div class="product-container">
   <div class="alternate" v-if="itemlist.length==0">
      <img src="https://stores.maxfashion.in/VendorpageTheme/Enterprise/EThemeForMax/images/product-not-found.jpg">
   </div>
     <ProductitemComponent v-for="(data,index) in itemlist" :key="index" :item="data"/>
  </div>
</template>

<script>
import { mapGetters } from 'vuex';
import ProductitemComponent from "./ProductitemComponent.vue";
export default {
    
     components:
     {
        ProductitemComponent,
     },

     computed:
     {
        ...mapGetters({
            itemlist:'getItemlist',
        })
     },

     created()
     {
        this.$store.dispatch('getfooditemsfromservice')
     }
}
</script>

<style>
.product-container
{  

   
   margin-top:80px;
   margin-left:20px;
   /* margin-right:600px; */
   display:flex;
   flex-wrap:wrap;
   flex-direction:row;
      width:100%;

}

@media only screen and (max-width: 770px) {
.product-container
{
   margin-top:750px;
   margin-left:300px;
     width:1100px;
     margin-left:400px;

}

}

@media only screen and (max-width: 280px) {
.product-container
{
  
   margin-left:250px;
   

}

}


img{
   height:200px;
   width:200px;
}

.alternate
{
   display: flex;
   align-items: center;
}
</style>