<template>
  <hello-world/>
</template>

<script>
  import HeaderComponent from '../components/HeaderComponent'

  export default {
    name: 'HomeView',

    components: {
      HeaderComponent,
    },
  }
</script>
