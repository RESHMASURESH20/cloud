import axios from 'axios';
export const getfooditems = ({success, error})=>{
    console.log("inside get rhisteer")
    const api ="http://10.30.1.159:8888/admin/getAll" 

    axios
    .get(api)
    .then((data)=>{     
      success && success(data)      
    }).catch((e) => {
        error && error(e)
    })
  }

export const searchfooditems = ({itemname,success,error})=>{
    console.log("inside get rhisteer")
    // const api ='http://10.30.1.159:8888/admin/search?name=${name}' 

    axios
    .get(`http://10.30.1.159:8888/admin/search?name=${itemname}`)
    .then((data)=>{     
      success && success(data)      
    }).catch((e) => {
        error && error(e)
    })
}
export const getuserid = ({username,success,error})=>{

  console.log("inside get rhisteer")

  // const api ='http://10.30.1.159:8888/admin/search?name=${name}'



  axios

  .get(`http://10.30.1.159:8084/getUserId/name?name=${username}`)

  .then((data)=>{     

    success && success(data)      

  }).catch((e) => {

      error && error(e)

  })

}