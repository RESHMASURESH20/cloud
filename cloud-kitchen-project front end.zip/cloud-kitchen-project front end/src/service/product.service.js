import axios from 'axios';
export const createProduct = ({success, error,object})=>{
  console.log("inside create",object)
  const api ="http://10.30.1.159:8888/admin/insert" 

  axios
  .post(api,object)
  .then((response)=>{     
    success && success(response)      
  }).catch((e) => {
      error && error(e)
  })
}
export const getHistory = ({success, error})=>{
  console.log("inside get History")
  const api ="http://10.30.1.159:8889/orders/getOrder" 

  axios
  .get(api)
  .then((response)=>{  
    console.log(response)   
    success && success(response)      
  }).catch((e) => {
      error && error(e)
  })
}
export const getProduct = ({success, error})=>{
    console.log("inside get Product")
    const api ="http://10.30.1.159:8888/admin/getAll" 

    axios
    .get(api)
    .then((response)=>{     
      success && success(response)      
    }).catch((e) => {
        error && error(e)
    })
  }
  export const deleteProduct = ({success, error,object})=>{
    console.log("inside get register")
    // const api =`http://10.30.1.159:8888/admin/deleteById/?id=${object}`
    const api =`http://10.30.1.159:8888/admin/deleteById/${object}`
    console.log(api)
    axios
    .delete(api)
    .then((response)=>{     
      success && success(response)      
    }).catch((e) => {
        error && error(e)
    })
  }

  export const editProduct = ({success, error,object})=>{
    console.log("inside edit")
    // const api =`http://10.30.1.159:8888/admin/deleteById/?id=${object}`
    const api ='http://10.30.1.159:8888/admin/updateById'
    console.log(api,object)
    axios
    .put(api,object)
    .then((response)=>{     
      success && success(response)      
    }).catch((e) => {
        error && error(e)
    })
  }
  
  export const orderProduct = ({success, error,object})=>{
    console.log("inside get rhisteer")
    const api =`http://10.30.1.159:8085/order/insertOrders`
    console.log(api)
    axios
    .post(api,object)
    .then((response)=>{     
      success && success(response)      
    }).catch((e) => {
        error && error(e)
    })

  }
  export const cancelProduct = ({success, error,object})=>{
    console.log("inside get rhisteer")
    const api =`http://10.30.1.159:8085/order/cancelOrders`
    console.log(api)
    axios
    .post(api,object)
    .then((response)=>{  
      console.log(response)   
      success && success(response)      
    }).catch((e) => {
      console.log(e)   
        error && error(e)
    })
  }
  export const deliverOrder= ({success, error,object})=>{
    console.log("inside get rhisteer")
    const api =`http://10.30.1.159:8889/orders/orderDelivered/${object}`
    console.log(api)
    axios
    .post(api,object)
    .then((response)=>{  
      console.log(response)   
      success && success(response)      
    }).catch((e) => {
      console.log(e)   
        error && error(e)
    })
  }
  export const UserHistory = ({success, error,value})=>{
    console.log("inside get History")
    const api =`http://10.30.1.159:8889/orders/getAllOrderById/${value}`
    axios
    .get(api)
    .then((response)=>{  
      console.log('user history',response)   
      success && success(response)      
    }).catch((e) => {
        error && error(e)
    })
  }
  export const  cancelOrder = ({date,order,success, error})=>{

    console.log("inside get order")
  
    const api =""
  
    axios
  
    .post(api,date,order)
  
    .then((res)=>{     
  
      console.log(res)
  
      success && success(res)      
  
    }).catch((e) => {
  
        error && error(e)
  
    })
  
  }