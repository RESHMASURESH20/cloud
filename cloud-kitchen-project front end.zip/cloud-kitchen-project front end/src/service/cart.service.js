import axios from 'axios';
export const getcartitems = ({userid,success, error})=>{
    console.log("inside get rhisteer")
    const api =`http://10.30.1.86:8898/cart/getCartByUserid/${userid}` 
    axios
    .get(api)
    .then((res)=>{     
      console.log(res)
      success && success(res)      
    }).catch((e) => {
        error && error(e)
    })
  }

  export const insertcartitem = ({payload,success, error})=>{
      console.log("inside get rhisteer")
      const api ="http://10.30.1.86:8898/cart/add"
      axios
      .post(api,payload)
      .then((res)=>{     
        success && success(res)      
      }).catch((e) => {
          error && error(e)
      })
    }  

export const increasequantity = ({userid,productid,success,error})=>{
    console.log("inside get rhisteer")
    // const api ='http://10.30.1.159:8888/admin/search?name=${name}' 

    axios
    .put(`http://10.30.1.159:8898/cart/increment/${userid}/${productid}`)
    .then((data)=>{     
      success && success(data)      
    }).catch((e) => {
        error && error(e)
    })
}


export const decreasequantity = ({userid,productid,success,error})=>{
    console.log("inside get rhisteer")
    // const api ='http://10.30.1.159:8888/admin/search?name=${name}' 

    axios
    .put(`http://10.30.1.159:8898/cart/decrement/${userid}/${productid}`)
    .then((data)=>{     
      success && success(data)      
    }).catch((e) => {
        error && error(e)
    })
}

export const placeorder  = ({order,success, error})=>{
  console.log("inside post",order)
  const api ="http://10.30.1.159:8889/orders/placeOrder"
  axios
  .post(api,order)
  .then((res)=>{     
    console.log(res,order)
    success && success(res)      
  }).catch((e) => {
      error && error(e)
  })
}

export const getorderlist = ({id,success, error})=>{
  console.log("inside get order",id)
  const api =`http://10.30.1.159:8889/orders/getOrderById/${id}` 
  axios
  .get(api)
  .then((res)=>{     
    console.log(res)
    success && success(res)      
  }).catch((e) => {
      error && error(e)
  })
}

export const  cancelOrder = ({date,orderid,success, error})=>{
  console.log("inside get order",date,orderid)
  const api =`http://10.30.1.159:8889/orders/checkForStatus/${orderid}/str?str=${date}`
  axios
  .post(api,orderid,date)
  .then((res)=>{     
    console.log("inside block",res)
    success && success(res)      
  }).catch((e) => {
      error && error(e)
  })
}

export const  confirmcancelOrder = ({orderid,success, error})=>{
  console.log("inside get order",orderid)
  const api =`http://10.30.1.159:8889/orders/cancelOrder/${orderid}`
  axios
  .post(api,orderid)
  .then((res)=>{     
    console.log("inside confirm block",res)
    success && success(res)      
  }).catch((e) => {
      error && error(e)
  })
}

 
export const deleteitem = ({userid,productid,success,error})=>{

  console.log("inside get rhisteer")

  // const api ='http://10.30.1.159:8888/admin/search?name=${name}'



  axios

  .delete(`http://10.30.1.86:8898/cart/delete/${userid}/${productid}`)

  .then((data)=>{     

    success && success(data)      

  }).catch((e) => {

      error && error(e)

  })

}




