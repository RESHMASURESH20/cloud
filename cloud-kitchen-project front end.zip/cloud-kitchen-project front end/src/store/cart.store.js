import {getcartitems,insertcartitem,increasequantity,decreasequantity,deleteitem} from "../service/cart.service"
export default {
    state : {
        cartlist : [],
        final:{
        totalPrice :0,
         netprice:0,
         discount:18,
         
        },
        successFlag:false
        
    },
    getters :{
        getCartlist(state){
            return state.cartlist;
        },
        getTotalPrice(state)
        {
            state.final.totalPrice=0,
            state.final.netprice=0
            state.cartlist.forEach((element) => {
                state.final.totalPrice += element.price * element.quantity;
            });
            state.final.netprice = state.final.totalPrice + (state.final.totalPrice * state.final.discount) / 100;
            console.log(state.final.totalPrice+" "+state.final.netprice)
            return state.final
          },
          getFlag(state){
            return state.successFlag;
          }
           
    },
    mutations:{
       
        setCartlist(state,value)
        {
            state.cartlist=value;
             
        },
        setFlag(state,value){
            state.successFlag=value;
        }
    },
    actions : {
        getsuccessFlag(state,value){
            this.commit('setFlag',value)
            console.log("flag",state.successFlag)

        },
        getcartitemsfromservice(context,userid){
            getcartitems({
                userid,
                success : ({data}) => {
                    this.commit("setCartlist",data.products)
                    console.log("cart object");
                    console.log(data.products);
                },
                error : (e) => {
                //    alert(e)
                console.log(e)
                //    this.commit("setCartlist",[])
                },
            })
           console.log("WORKIng")
        },

        

        insertcartitemstoservice({dispatch},payload){
            insertcartitem({
                payload,
                success : (data) => {
                    // this.commit("setItemlist",data.data)
                    console.log(data);
                    dispatch('getcartitemsfromservice',localStorage.getItem("userid"))
                },
                error : (e) => {
                   alert(e)
                //    this.commit("setItemlist",[])
                },
            })
           console.log("WORKIng")
        },
        
        increaseservice({dispatch},payload){
            increasequantity({
                productid:payload.productid,
                userid:payload.userid,
                success : (data) => {
                    // this.commit("setItemlist",data.data)
                    console.log(data);
                    dispatch('getcartitemsfromservice',localStorage.getItem("userid"))
                },
                error : (e) => {
                   alert(e)
                //    this.commit("setItemlist",[])
                },
            })
           console.log("WORKIng")
        },
        decreaseservice({dispatch},payload){
            decreasequantity({
                productid:payload.productid,
                userid:payload.userid,
                success : (data) => {
                    // this.commit("setItemlist",data.data)
                    console.log(data);
                    dispatch('getcartitemsfromservice',localStorage.getItem("userid"))
                },
                error : (e) => {
                   alert(e)
                //    this.commit("setItemlist",[])
                },
            })
           console.log("WORKIng")
        },

        deleteitemservice({dispatch},payload){

            deleteitem({

                productid:payload.productid,

                userid:payload.userid,

                success : (data) => {

                    // this.commit("setItemlist",data.data)

                    console.log(data);

                    dispatch('getcartitemsfromservice',localStorage.getItem("userid"))

                },

                error : (e) => {

                   alert(e)

                //    this.commit("setItemlist",[])

                },

            })

           console.log("WORKIng")

        },
        
        

      
    }
}