import {getorderlist} from '../service/cart.service'

export default{
    state:{
        orderlist:{}
    },
    getters:{
        getorder(state)
        {
            console.log("getter",state.orderlist)
            return state.orderlist;
        },
        
    },
    mutations:{
        setorder(state,value){
            state.orderlist=value;
        }
    },
    actions:{
        GET_ORDER(context,id){
        getorderlist({
               id,
                success : ({data}) => {
                    this.commit('setorder',data)
                    console.log("GET ORDER DATA",data)
                },
                error : (e) => {
                   this.commit("setorder",{})
                   console.log(e)
                },
                
            })
           console.log("getorder")
        },
    }
}