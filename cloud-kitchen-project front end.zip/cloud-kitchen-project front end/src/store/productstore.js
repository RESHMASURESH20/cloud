import {getfooditems,searchfooditems,getuserid} from "../service/food.service"
export default {
    state : {
        itemlist : []
          
    },
    getters :{
        getItemlist(state){
            console.log("in get item",state)
            return state.itemlist;
        },
    },
    mutations : {
       
        setItemlist(state,value)
        {
            console.log("set item product")
            state.itemlist=value;
        }
    },
    
    actions : {
        getfooditemsfromservice(){
            getfooditems({
                success : (data) => {
                    this.commit("setItemlist",data.data)

                    console.log(data);
                },
                error : (e) => {
                   alert("error",e)
                   this.commit("setItemlist",[])
                },
            })
           console.log("WORKIng")
        },
        
        searchfooditemsfromservice(context,itemname){
            searchfooditems({itemname,
                success : (data) => {
                    this.commit("setItemlist",data.data)

                    console.log(data);
                },
                error : (e) => {
                   alert("error",e)
                   this.commit("setItemlist",[])
                },
            })
           console.log("WORKIng")
        },
        getuseridfromservice({dispatch},username){

            getuserid({

                username,

                success : (data) => {

                    this.commit("setUserid",data.data.userId)

                    dispatch('getcartitemsfromservice',data.data.userId)

                    localStorage.setItem('userid',data.data.userId)
                    localStorage.setItem('name',data.data.name)
                    localStorage.setItem('username',data.data.userName)
                    console.log(data.data)
                    localStorage.setItem('phone',data.data.phoneNo)


                    console.log("returned",data.data.userId);

                },

                error : (e) => {

                   alert("error",e)

                   this.commit("setUserid",0)

                },

            })

           console.log("WORKIng")

        },
      
    }
}