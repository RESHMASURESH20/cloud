import Vuex from 'vuex';
import itemsStore from './items.store';
import cartStore from './cart.store';
import order from '../store/order'
import productstore from './productstore'
import Vue from 'vue'
Vue.use(Vuex)
export default new Vuex.Store({
modules:{
  itemsStore,
  cartStore,
  order,
  productstore
}
});
