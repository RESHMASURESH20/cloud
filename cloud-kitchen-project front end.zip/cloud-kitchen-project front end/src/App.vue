<template>
  <v-app>
     <router-view/>
  </v-app>
</template>

<script>
export default {
    name: "App",
    data: () => ({
    //
    }),
};
</script>
<style>
*{
  font-family: Arial, Helvetica, sans-serif!important;
}
</style>